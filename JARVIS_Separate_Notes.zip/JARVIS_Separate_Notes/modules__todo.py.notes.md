# Notes for `modules/todo.py`

## File purpose
Todo-list module. It detects task-management commands and stores tasks in a JSON file.

## Main classes and functions

- `class TodoManager` starts at line 16: groups related state and behaviours. It is used because JARVIS needs reusable objects rather than loose code everywhere.
- `__init__()` starts at line 18: reusable logic block
- `load()` starts at line 26: reusable logic block
- `save()` starts at line 33: reusable logic block
- `_now()` starts at line 39: reusable logic block
- `_next_id()` starts at line 43: reusable logic block
- `add()` starts at line 48: reusable logic block
- `complete()` starts at line 62: reusable logic block
- `delete()` starts at line 74: reusable logic block
- `update()` starts at line 82: reusable logic block
- `list_todos()` starts at line 91: reusable logic block
- `morning_summary()` starts at line 105: reusable logic block — Short summary for morning greeting.
- `_find()` starts at line 125: reusable logic block — Find task by ID number or keyword match.
- `parse_and_handle()` starts at line 141: reusable logic block

## Why the sequence/order matters

The file follows the usual Python order: documentation, imports, constants/classes/functions, and finally executable entry logic. That sequence makes dependencies available before they are used.

## Line-by-line notes

| Line | Code | Explanation |
|---:|---|---|
| 1 | `"""` | Docstring/comment text: explains the purpose of the file, class, or function for humans and tools. |
| 2 | `modules/todo.py` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 3 | `Full voice-controlled todo list.` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 4 | `Add, complete, delete, update, and list tasks by voice.` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 5 | `"""` | Docstring/comment text: explains the purpose of the file, class, or function for humans and tools. |
| 6 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 7 | `import json` | Imports a module so this file can use features that are not built into the current namespace. |
| 8 | `import re` | Imports a module so this file can use features that are not built into the current namespace. |
| 9 | `from pathlib import Path` | Imports selected classes/functions/constants from another module to keep this file focused and avoid repeating code. |
| 10 | `from datetime import datetime` | Imports selected classes/functions/constants from another module to keep this file focused and avoid repeating code. |
| 11 | `import pytz` | Imports a module so this file can use features that are not built into the current namespace. |
| 12 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 13 | `from config import TODO_FILE, TIMEZONE` | Imports selected classes/functions/constants from another module to keep this file focused and avoid repeating code. |
| 14 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 15 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 16 | `class TodoManager:` | Defines a class, grouping related data and methods into one reusable object. |
| 17 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 18 | `    def __init__(self):` | Defines a function/method so this behaviour can be called later and kept separate from other logic. |
| 19 | `        self.path = Path(TODO_FILE)` | Uses filesystem path/file handling so the code can safely read, write, or check files. |
| 20 | `        self.path.parent.mkdir(parents=True, exist_ok=True)` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 21 | `        self.todos: list[dict] = []` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 22 | `        self.load()` | Closes a multi-line expression or function call that started on previous lines. |
| 23 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 24 | `    # ── Storage ────────────────────────────────────────────────────────────────` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 25 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 26 | `    def load(self):` | Defines a function/method so this behaviour can be called later and kept separate from other logic. |
| 27 | `        if self.path.exists():` | Conditional check: chooses the next action depending on the current state or user input. |
| 28 | `            try:` | Starts error-handling block so failures can be caught without crashing the whole assistant. |
| 29 | `                self.todos = json.loads(self.path.read_text(encoding="utf-8"))` | Uses filesystem path/file handling so the code can safely read, write, or check files. |
| 30 | `            except Exception:` | Handles a specific failure path; this keeps the program stable when something goes wrong. |
| 31 | `                self.todos = []` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 32 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 33 | `    def save(self):` | Defines a function/method so this behaviour can be called later and kept separate from other logic. |
| 34 | `        self.path.write_text(` | Uses filesystem path/file handling so the code can safely read, write, or check files. |
| 35 | `            json.dumps(self.todos, indent=2, ensure_ascii=False),` | Reads or writes JSON, which is used here because memory/todo data must persist after the program closes. |
| 36 | `            encoding="utf-8"` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 37 | `        )` | Closes a multi-line expression or function call that started on previous lines. |
| 38 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 39 | `    def _now(self) -> str:` | Defines a function/method so this behaviour can be called later and kept separate from other logic. |
| 40 | `        tz = pytz.timezone(TIMEZONE)` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 41 | `        return datetime.now(tz).isoformat()` | Returns a value to the caller and usually ends the current function. |
| 42 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 43 | `    def _next_id(self) -> int:` | Defines a function/method so this behaviour can be called later and kept separate from other logic. |
| 44 | `        return max((t["id"] for t in self.todos), default=0) + 1` | Returns a value to the caller and usually ends the current function. |
| 45 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 46 | `    # ── CRUD ───────────────────────────────────────────────────────────────────` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 47 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 48 | `    def add(self, task: str, priority: str = "normal") -> str:` | Defines a function/method so this behaviour can be called later and kept separate from other logic. |
| 49 | `        todo = {` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 50 | `            "id":       self._next_id(),` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 51 | `            "task":     task.strip(),` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 52 | `            "done":     False,` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 53 | `            "priority": priority,   # low / normal / high` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 54 | `            "created":  self._now(),` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 55 | `            "completed": None,` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 56 | `        }` | Closes a multi-line expression or function call that started on previous lines. |
| 57 | `        self.todos.append(todo)` | Closes a multi-line expression or function call that started on previous lines. |
| 58 | `        self.save()` | Closes a multi-line expression or function call that started on previous lines. |
| 59 | `        count = len([t for t in self.todos if not t["done"]])` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 60 | `        return f"Added '{task}' to your list. You now have {count} pending task{'s' if count != 1 else ''}."` | Returns a value to the caller and usually ends the current function. |
| 61 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 62 | `    def complete(self, identifier: str) -> str:` | Defines a function/method so this behaviour can be called later and kept separate from other logic. |
| 63 | `        todo = self._find(identifier)` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 64 | `        if not todo:` | Conditional check: chooses the next action depending on the current state or user input. |
| 65 | `            return f"I couldn't find a task matching '{identifier}'."` | Returns a value to the caller and usually ends the current function. |
| 66 | `        if todo["done"]:` | Conditional check: chooses the next action depending on the current state or user input. |
| 67 | `            return f"'{todo['task']}' is already marked as done."` | Returns a value to the caller and usually ends the current function. |
| 68 | `        todo["done"] = True` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 69 | `        todo["completed"] = self._now()` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 70 | `        self.save()` | Closes a multi-line expression or function call that started on previous lines. |
| 71 | `        remaining = len([t for t in self.todos if not t["done"]])` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 72 | `        return f"Marked '{todo['task']}' as done. {remaining} task{'s' if remaining != 1 else ''} remaining."` | Returns a value to the caller and usually ends the current function. |
| 73 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 74 | `    def delete(self, identifier: str) -> str:` | Defines a function/method so this behaviour can be called later and kept separate from other logic. |
| 75 | `        todo = self._find(identifier)` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 76 | `        if not todo:` | Conditional check: chooses the next action depending on the current state or user input. |
| 77 | `            return f"I couldn't find a task matching '{identifier}'."` | Returns a value to the caller and usually ends the current function. |
| 78 | `        self.todos = [t for t in self.todos if t["id"] != todo["id"]]` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 79 | `        self.save()` | Closes a multi-line expression or function call that started on previous lines. |
| 80 | `        return f"Deleted '{todo['task']}' from your list."` | Returns a value to the caller and usually ends the current function. |
| 81 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 82 | `    def update(self, identifier: str, new_text: str) -> str:` | Defines a function/method so this behaviour can be called later and kept separate from other logic. |
| 83 | `        todo = self._find(identifier)` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 84 | `        if not todo:` | Conditional check: chooses the next action depending on the current state or user input. |
| 85 | `            return f"I couldn't find a task matching '{identifier}'."` | Returns a value to the caller and usually ends the current function. |
| 86 | `        old = todo["task"]` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 87 | `        todo["task"] = new_text.strip()` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 88 | `        self.save()` | Closes a multi-line expression or function call that started on previous lines. |
| 89 | `        return f"Updated '{old}' to '{new_text}'."` | Returns a value to the caller and usually ends the current function. |
| 90 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 91 | `    def list_todos(self, show_done: bool = False) -> str:` | Defines a function/method so this behaviour can be called later and kept separate from other logic. |
| 92 | `        items = self.todos if show_done else [t for t in self.todos if not t["done"]]` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 93 | `        if not items:` | Conditional check: chooses the next action depending on the current state or user input. |
| 94 | `            return "Your todo list is empty — you're all caught up!" if not show_done else "No tasks at all."` | Returns a value to the caller and usually ends the current function. |
| 95 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 96 | `        lines = []` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 97 | `        for t in items:` | Loop: repeats the following block for every item in a collection or range. |
| 98 | `            status = "✓" if t["done"] else "○"` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 99 | `            pri    = " [HIGH]" if t["priority"] == "high" else ""` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 100 | `            lines.append(f"  {status} {t['id']}. {t['task']}{pri}")` | Closes a multi-line expression or function call that started on previous lines. |
| 101 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 102 | `        header = f"You have {len(items)} task{'s' if len(items) != 1 else ''}:"` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 103 | `        return header + "\n" + "\n".join(lines)` | Returns a value to the caller and usually ends the current function. |
| 104 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 105 | `    def morning_summary(self) -> str:` | Defines a function/method so this behaviour can be called later and kept separate from other logic. |
| 106 | `        """Short summary for morning greeting."""` | Docstring/comment text: explains the purpose of the file, class, or function for humans and tools. |
| 107 | `        pending = [t for t in self.todos if not t["done"]]` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 108 | `        high    = [t for t in pending if t.get("priority") == "high"]` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 109 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 110 | `        if not pending:` | Conditional check: chooses the next action depending on the current state or user input. |
| 111 | `            return "Your todo list is clear — great start to the day!"` | Returns a value to the caller and usually ends the current function. |
| 112 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 113 | `        summary = f"You've got {len(pending)} thing{'s' if len(pending) != 1 else ''} on your list"` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 114 | `        if high:` | Conditional check: chooses the next action depending on the current state or user input. |
| 115 | `            summary += f", including {len(high)} high-priority item{'s' if len(high) != 1 else ''}"` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 116 | `        summary += ". " + ", ".join(t["task"] for t in pending[:3])` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 117 | `        if len(pending) > 3:` | Conditional check: chooses the next action depending on the current state or user input. |
| 118 | `            summary += f" and {len(pending) - 3} more."` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 119 | `        else:` | Fallback branch used when no earlier condition matched. |
| 120 | `            summary += "."` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 121 | `        return summary` | Returns a value to the caller and usually ends the current function. |
| 122 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 123 | `    # ── Helpers ────────────────────────────────────────────────────────────────` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 124 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 125 | `    def _find(self, identifier: str) -> dict \| None:` | Defines a function/method so this behaviour can be called later and kept separate from other logic. |
| 126 | `        """Find task by ID number or keyword match."""` | Docstring/comment text: explains the purpose of the file, class, or function for humans and tools. |
| 127 | `        # By ID` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 128 | `        if identifier.strip().isdigit():` | Conditional check: chooses the next action depending on the current state or user input. |
| 129 | `            tid = int(identifier.strip())` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 130 | `            for t in self.todos:` | Loop: repeats the following block for every item in a collection or range. |
| 131 | `                if t["id"] == tid:` | Conditional check: chooses the next action depending on the current state or user input. |
| 132 | `                    return t` | Returns a value to the caller and usually ends the current function. |
| 133 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 134 | `        # By keyword` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 135 | `        ident_lower = identifier.lower()` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 136 | `        matches = [t for t in self.todos if ident_lower in t["task"].lower()]` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 137 | `        return matches[-1] if matches else None` | Returns a value to the caller and usually ends the current function. |
| 138 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 139 | `    # ── Intent parsing ─────────────────────────────────────────────────────────` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 140 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 141 | `    def parse_and_handle(self, text: str) -> str \| None:` | Defines a function/method so this behaviour can be called later and kept separate from other logic. |
| 142 | `        text_lower = text.lower().strip()` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 143 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 144 | `        # List todos` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 145 | `        if re.search(r"\b(list\|show\|what'?s? on\|read\|tell me)\b.+\b(todo\|to-do\|to do\|tasks?\|list)\b", text_lower):` | Conditional check: chooses the next action depending on the current state or user input. |
| 146 | `            show_done = "done" in text_lower or "completed" in text_lower` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 147 | `            return self.list_todos(show_done)` | Returns a value to the caller and usually ends the current function. |
| 148 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 149 | `        if re.search(r"\bmy (todo\|to-do\|to do\|tasks?\|list)\b", text_lower):` | Conditional check: chooses the next action depending on the current state or user input. |
| 150 | `            return self.list_todos()` | Returns a value to the caller and usually ends the current function. |
| 151 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 152 | `        # Add task` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 153 | `        m = re.search(` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 154 | `            r"\b(add\|create\|new\|put\|remind me to\|note down)\b\s+(?:a\s+)?(?:task\s+)?(?:to\s+)?(.+?)(?:\s+to\s+(?:my\s+)?(?:list\|todos?))?$",` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 155 | `            text_lower` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 156 | `        )` | Closes a multi-line expression or function call that started on previous lines. |
| 157 | `        if m:` | Conditional check: chooses the next action depending on the current state or user input. |
| 158 | `            task = m.group(2).strip()` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 159 | `            # Detect priority` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 160 | `            priority = "normal"` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 161 | `            if re.search(r"\b(urgent\|asap\|high priority\|important)\b", task):` | Conditional check: chooses the next action depending on the current state or user input. |
| 162 | `                priority = "high"` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 163 | `                task = re.sub(r"\b(urgent\|asap\|high priority\|important)\b", "", task).strip()` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 164 | `            return self.add(task, priority)` | Returns a value to the caller and usually ends the current function. |
| 165 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 166 | `        # Complete / tick off task` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 167 | `        m = re.search(` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 168 | `            r"\b(done\|complete\|finish\|tick off\|mark as done\|completed)\b\s+(?:task\s+)?(.+)",` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 169 | `            text_lower` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 170 | `        )` | Closes a multi-line expression or function call that started on previous lines. |
| 171 | `        if m:` | Conditional check: chooses the next action depending on the current state or user input. |
| 172 | `            return self.complete(m.group(2).strip())` | Returns a value to the caller and usually ends the current function. |
| 173 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 174 | `        # Delete task` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 175 | `        m = re.search(r"\b(delete\|remove\|cancel\|drop)\b\s+(?:task\s+)?(.+)", text_lower)` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 176 | `        if m:` | Conditional check: chooses the next action depending on the current state or user input. |
| 177 | `            return self.delete(m.group(2).strip())` | Returns a value to the caller and usually ends the current function. |
| 178 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 179 | `        # Update task` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 180 | `        m = re.search(r"\b(update\|change\|rename\|edit)\b\s+(?:task\s+)?(.+?)\s+to\s+(.+)", text_lower)` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 181 | `        if m:` | Conditional check: chooses the next action depending on the current state or user input. |
| 182 | `            return self.update(m.group(2).strip(), m.group(3).strip())` | Returns a value to the caller and usually ends the current function. |
| 183 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 184 | `        return None` | Returns a value to the caller and usually ends the current function. |
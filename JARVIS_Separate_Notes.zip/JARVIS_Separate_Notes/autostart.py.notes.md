# Notes for `autostart.py`

## File purpose
Installs or removes JARVIS from Windows startup. It first tries Windows Task Scheduler, then falls back to creating a Startup-folder BAT file.

## Main classes and functions

- `install_startup()` starts at line 13: reusable logic block — Add JARVIS to Windows startup via Task Scheduler.
- `_install_via_startup_folder()` starts at line 43: reusable logic block — Fallback: add a .bat file to Windows startup folder.
- `remove_startup()` starts at line 58: reusable logic block — Remove JARVIS from startup.

## Why the sequence/order matters

The script tries the stronger Task Scheduler method first; if that fails it uses the simpler Startup folder fallback. The remove function is separate so setup and cleanup are not mixed.

## Line-by-line notes

| Line | Code | Explanation |
|---:|---|---|
| 1 | `"""` | Docstring/comment text: explains the purpose of the file, class, or function for humans and tools. |
| 2 | `autostart.py` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 3 | `Run this once to install JARVIS as a Windows startup program.` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 4 | `After running, JARVIS will launch automatically every time you log in.` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 5 | `"""` | Docstring/comment text: explains the purpose of the file, class, or function for humans and tools. |
| 6 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 7 | `import os` | Imports a module so this file can use features that are not built into the current namespace. |
| 8 | `import sys` | Imports a module so this file can use features that are not built into the current namespace. |
| 9 | `import subprocess` | Imports a module so this file can use features that are not built into the current namespace. |
| 10 | `from pathlib import Path` | Imports selected classes/functions/constants from another module to keep this file focused and avoid repeating code. |
| 11 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 12 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 13 | `def install_startup():` | Defines a function/method so this behaviour can be called later and kept separate from other logic. |
| 14 | `    """Add JARVIS to Windows startup via Task Scheduler."""` | Docstring/comment text: explains the purpose of the file, class, or function for humans and tools. |
| 15 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 16 | `    python_exe  = sys.executable` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 17 | `    jarvis_dir  = Path(__file__).parent.resolve()` | Uses filesystem path/file handling so the code can safely read, write, or check files. |
| 18 | `    main_script = jarvis_dir / "main.py"` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 19 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 20 | `    task_name = "JARVIS_Autostart"` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 21 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 22 | `    # Build the scheduled task command` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 23 | `    cmd = (` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 24 | `        f'schtasks /create /tn "{task_name}" '` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 25 | `        f'/tr "\\"{python_exe}\\" \\"{main_script}\\"" '` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 26 | `        f'/sc onlogon '` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 27 | `        f'/rl limited '` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 28 | `        f'/f'   # force overwrite if exists` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 29 | `    )` | Closes a multi-line expression or function call that started on previous lines. |
| 30 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 31 | `    result = subprocess.run(cmd, shell=True, capture_output=True, text=True)` | Runs an external operating-system command or program; needed for launching apps or Windows tasks. |
| 32 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 33 | `    if result.returncode == 0:` | Conditional check: chooses the next action depending on the current state or user input. |
| 34 | `        print("✅ JARVIS will now start automatically when you log in.")` | Displays debug/status text in the terminal so the developer knows what is happening. |
| 35 | `        print(f"   Script: {main_script}")` | Displays debug/status text in the terminal so the developer knows what is happening. |
| 36 | `        print(f"   Python: {python_exe}")` | Displays debug/status text in the terminal so the developer knows what is happening. |
| 37 | `        print(f"\n   To remove: schtasks /delete /tn \"{task_name}\" /f")` | Displays debug/status text in the terminal so the developer knows what is happening. |
| 38 | `    else:` | Fallback branch used when no earlier condition matched. |
| 39 | `        print("❌ Task Scheduler failed. Trying startup folder method...")` | Displays debug/status text in the terminal so the developer knows what is happening. |
| 40 | `        _install_via_startup_folder(python_exe, main_script)` | Closes a multi-line expression or function call that started on previous lines. |
| 41 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 42 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 43 | `def _install_via_startup_folder(python_exe: str, main_script: Path):` | Defines a function/method so this behaviour can be called later and kept separate from other logic. |
| 44 | `    """Fallback: add a .bat file to Windows startup folder."""` | Docstring/comment text: explains the purpose of the file, class, or function for humans and tools. |
| 45 | `    startup = Path(os.environ["APPDATA"]) / "Microsoft/Windows/Start Menu/Programs/Startup"` | Uses filesystem path/file handling so the code can safely read, write, or check files. |
| 46 | `    bat_path = startup / "JARVIS.bat"` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 47 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 48 | `    # The bat file changes to the right directory first` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 49 | `    bat_content = f"""@echo off` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 50 | `cd /d "{main_script.parent}"` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 51 | `start /min "" "{python_exe}" "{main_script}"` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 52 | `"""` | Docstring/comment text: explains the purpose of the file, class, or function for humans and tools. |
| 53 | `    bat_path.write_text(bat_content)` | Uses filesystem path/file handling so the code can safely read, write, or check files. |
| 54 | `    print(f"✅ Added JARVIS to startup folder: {bat_path}")` | Displays debug/status text in the terminal so the developer knows what is happening. |
| 55 | `    print("   JARVIS will launch minimised every time you log in.")` | Displays debug/status text in the terminal so the developer knows what is happening. |
| 56 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 57 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 58 | `def remove_startup():` | Defines a function/method so this behaviour can be called later and kept separate from other logic. |
| 59 | `    """Remove JARVIS from startup."""` | Docstring/comment text: explains the purpose of the file, class, or function for humans and tools. |
| 60 | `    subprocess.run('schtasks /delete /tn "JARVIS_Autostart" /f', shell=True)` | Runs an external operating-system command or program; needed for launching apps or Windows tasks. |
| 61 | `    # Also remove bat if it exists` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 62 | `    startup = Path(os.environ.get("APPDATA", "")) / "Microsoft/Windows/Start Menu/Programs/Startup/JARVIS.bat"` | Uses filesystem path/file handling so the code can safely read, write, or check files. |
| 63 | `    if startup.exists():` | Conditional check: chooses the next action depending on the current state or user input. |
| 64 | `        startup.unlink()` | Closes a multi-line expression or function call that started on previous lines. |
| 65 | `    print("✅ JARVIS removed from startup.")` | Displays debug/status text in the terminal so the developer knows what is happening. |
| 66 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 67 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 68 | `if __name__ == "__main__":` | Entry-point guard: this block runs only when the file is executed directly, not when imported by another file. |
| 69 | `    import argparse` | Imports a module so this file can use features that are not built into the current namespace. |
| 70 | `    parser = argparse.ArgumentParser()` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 71 | `    parser.add_argument("--remove", action="store_true", help="Remove from startup")` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 72 | `    args = parser.parse_args()` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 73 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 74 | `    if args.remove:` | Conditional check: chooses the next action depending on the current state or user input. |
| 75 | `        remove_startup()` | Closes a multi-line expression or function call that started on previous lines. |
| 76 | `    else:` | Fallback branch used when no earlier condition matched. |
| 77 | `        install_startup()` | Closes a multi-line expression or function call that started on previous lines. |
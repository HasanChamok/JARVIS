# Notes for `jarvis.py`

## File purpose
Main orchestrator/brain. It receives speech text, routes it through modules in a fixed order, falls back to Ollama, saves memory, and speaks the answer.

## Main classes and functions

- `class JARVIS` starts at line 28: groups related state and behaviours. It is used because JARVIS needs reusable objects rather than loose code everywhere.
- `__init__()` starts at line 30: reusable logic block
- `_status()` starts at line 55: reusable logic block
- `on_speech()` starts at line 61: reusable logic block — Called by Listener thread when a complete utterance is transcribed.
Full pipeline: route → respond → speak.
- `_route()` starts at line 89: reusable logic block — Try each module in order. First match wins.
If nothing matches, fall through to LLM.
- `_llm()` starts at line 121: reusable logic block — Send to Ollama with full system prompt + conversation history.
- `morning_greeting()` starts at line 147: reusable logic block — Full greeting spoken on startup:
hi + time + weather + todo summary.
- `start()` starts at line 161: reusable logic block — Start JARVIS. Blocks until shutdown.

## Why the sequence/order matters

Imports come first, then the `JARVIS` class creates all modules in `__init__`, then speech enters `on_speech`, then routing decides whether a module or the LLM answers. This order prevents the LLM from being called when a simpler module can handle the request.

## Line-by-line notes

| Line | Code | Explanation |
|---:|---|---|
| 1 | `"""` | Docstring/comment text: explains the purpose of the file, class, or function for humans and tools. |
| 2 | `jarvis.py — Main brain. Orchestrates all modules.` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 3 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 4 | `Architecture:` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 5 | `  Listener (mic) → on_speech() → intent router → module or LLM → Speaker (TTS)` | Closes a multi-line expression or function call that started on previous lines. |
| 6 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 7 | `Module pipeline (in order):` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 8 | `  1. personality.py  — greetings, jokes, hello` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 9 | `  2. todo.py         — add/delete/update/list tasks` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 10 | `  3. memory.py       — remember facts, search history` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 11 | `  4. files.py        — open files and folders` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 12 | `  5. apps.py         — launch applications` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 13 | `  6. realtime.py     — weather, time, search, system stats` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 14 | `  7. LLM fallback    — everything else → Ollama` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 15 | `"""` | Docstring/comment text: explains the purpose of the file, class, or function for humans and tools. |
| 16 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 17 | `import threading` | Imports a module so this file can use features that are not built into the current namespace. |
| 18 | `import ollama` | Imports a module so this file can use features that are not built into the current namespace. |
| 19 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 20 | `from config import OLLAMA_MODEL, OLLAMA_HOST, USER_NAME` | Imports selected classes/functions/constants from another module to keep this file focused and avoid repeating code. |
| 21 | `from modules.speech      import Listener, Speaker` | Imports selected classes/functions/constants from another module to keep this file focused and avoid repeating code. |
| 22 | `from modules.memory      import Memory` | Imports selected classes/functions/constants from another module to keep this file focused and avoid repeating code. |
| 23 | `from modules.todo        import TodoManager` | Imports selected classes/functions/constants from another module to keep this file focused and avoid repeating code. |
| 24 | `from modules import files, apps, realtime, personality` | Imports selected classes/functions/constants from another module to keep this file focused and avoid repeating code. |
| 25 | `from modules.realtime import get_location` | Imports selected classes/functions/constants from another module to keep this file focused and avoid repeating code. |
| 26 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 27 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 28 | `class JARVIS:` | Defines a class, grouping related data and methods into one reusable object. |
| 29 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 30 | `    def __init__(self, status_callback=None):` | Defines a function/method so this behaviour can be called later and kept separate from other logic. |
| 31 | `        print("\n[JARVIS] Booting up...\n")` | Displays debug/status text in the terminal so the developer knows what is happening. |
| 32 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 33 | `        # ── Core modules ───────────────────────────────────────────────────────` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 34 | `        self.memory      = Memory()` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 35 | `        self.todos       = TodoManager()` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 36 | `        self.speaker     = Speaker()` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 37 | `        self.joke_engine = personality.JokeEngine()` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 38 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 39 | `        # ── Speech ─────────────────────────────────────────────────────────────` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 40 | `        self.listener = Listener(on_speech_callback=self.on_speech)` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 41 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 42 | `        # ── State ──────────────────────────────────────────────────────────────` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 43 | `        self.running     = False` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 44 | `        self.status_cb   = status_callback   # hook for GUI` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 45 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 46 | `        # ── Weather cache (fetch once per session) ─────────────────────────────` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 47 | `        self._cached_weather = realtime.get_weather()` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 48 | `        # Auto-detect location` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 49 | `        self.location = get_location()` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 50 | `        print(f"[JARVIS] Location: {self.location['city']}, {self.location['country']}")` | Displays debug/status text in the terminal so the developer knows what is happening. |
| 51 | `        print("[JARVIS] All systems ready.\n")` | Displays debug/status text in the terminal so the developer knows what is happening. |
| 52 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 53 | `    # ── Status hook for GUI ────────────────────────────────────────────────────` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 54 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 55 | `    def _status(self, state: str, text: str = ""):` | Defines a function/method so this behaviour can be called later and kept separate from other logic. |
| 56 | `        if self.status_cb:` | Conditional check: chooses the next action depending on the current state or user input. |
| 57 | `            self.status_cb(state, text)` | Closes a multi-line expression or function call that started on previous lines. |
| 58 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 59 | `    # ── Main entry: called when user finishes speaking ─────────────────────────` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 60 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 61 | `    def on_speech(self, text: str):` | Defines a function/method so this behaviour can be called later and kept separate from other logic. |
| 62 | `        """` | Docstring/comment text: explains the purpose of the file, class, or function for humans and tools. |
| 63 | `        Called by Listener thread when a complete utterance is transcribed.` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 64 | `        Full pipeline: route → respond → speak.` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 65 | `        """` | Docstring/comment text: explains the purpose of the file, class, or function for humans and tools. |
| 66 | `        print(f"\n[YOU]    {text}")` | Displays debug/status text in the terminal so the developer knows what is happening. |
| 67 | `        self._status("thinking", text)` | Closes a multi-line expression or function call that started on previous lines. |
| 68 | `        self.listener.pause()   # don't pick up JARVIS's own voice` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 69 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 70 | `        response = self._route(text)` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 71 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 72 | `        # Optionally append a joke` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 73 | `        response = self.joke_engine.maybe_append_joke(response)` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 74 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 75 | `        print(f"[JARVIS] {response}\n")` | Displays debug/status text in the terminal so the developer knows what is happening. |
| 76 | `        self._status("speaking", response)` | Closes a multi-line expression or function call that started on previous lines. |
| 77 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 78 | `        # Save to permanent memory` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 79 | `        self.memory.add("user",      text)` | Closes a multi-line expression or function call that started on previous lines. |
| 80 | `        self.memory.add("assistant", response)` | Closes a multi-line expression or function call that started on previous lines. |
| 81 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 82 | `        # Speak, then resume listening` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 83 | `        self.speaker.speak(response)` | Closes a multi-line expression or function call that started on previous lines. |
| 84 | `        self._status("listening", "")` | Closes a multi-line expression or function call that started on previous lines. |
| 85 | `        self.listener.resume()` | Closes a multi-line expression or function call that started on previous lines. |
| 86 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 87 | `    # ── Intent router ──────────────────────────────────────────────────────────` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 88 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 89 | `    def _route(self, text: str) -> str:` | Defines a function/method so this behaviour can be called later and kept separate from other logic. |
| 90 | `        """` | Docstring/comment text: explains the purpose of the file, class, or function for humans and tools. |
| 91 | `        Try each module in order. First match wins.` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 92 | `        If nothing matches, fall through to LLM.` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 93 | `        """` | Docstring/comment text: explains the purpose of the file, class, or function for humans and tools. |
| 94 | `        text_lower = text.lower().strip()` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 95 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 96 | `        # Exit` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 97 | `        if any(w in text_lower for w in ["goodbye", "shut down", "exit jarvis", "stop jarvis", "go offline"]):` | Conditional check: chooses the next action depending on the current state or user input. |
| 98 | `            self.running = False` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 99 | `            return f"Going offline. Take care of yourself, {USER_NAME}."` | Returns a value to the caller and usually ends the current function. |
| 100 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 101 | `        # Module pipeline` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 102 | `        handlers = [` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 103 | `            personality.parse_and_handle,` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 104 | `            self.todos.parse_and_handle,` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 105 | `            self.memory.parse_and_handle,` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 106 | `            files.parse_and_handle,` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 107 | `            apps.parse_and_handle,` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 108 | `            realtime.parse_and_handle,` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 109 | `        ]` | Closes a multi-line expression or function call that started on previous lines. |
| 110 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 111 | `        for handler in handlers:` | Loop: repeats the following block for every item in a collection or range. |
| 112 | `            result = handler(text)` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 113 | `            if result is not None:` | Conditional check: chooses the next action depending on the current state or user input. |
| 114 | `                return result` | Returns a value to the caller and usually ends the current function. |
| 115 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 116 | `        # Nothing matched — send to LLM` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 117 | `        return self._llm(text)` | Returns a value to the caller and usually ends the current function. |
| 118 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 119 | `    # ── LLM call ───────────────────────────────────────────────────────────────` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 120 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 121 | `    def _llm(self, user_text: str, tool_result: str = None) -> str:` | Defines a function/method so this behaviour can be called later and kept separate from other logic. |
| 122 | `        """Send to Ollama with full system prompt + conversation history."""` | Docstring/comment text: explains the purpose of the file, class, or function for humans and tools. |
| 123 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 124 | `        system_prompt = personality.build_system_prompt(` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 125 | `            weather      = self._cached_weather,` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 126 | `            facts_string = self.memory.get_facts_string(),` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 127 | `        )` | Closes a multi-line expression or function call that started on previous lines. |
| 128 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 129 | `        messages = [{"role": "system", "content": system_prompt}]` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 130 | `        messages += self.memory.get_context_messages()` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 131 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 132 | `        # If a tool gave us extra data, include it` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 133 | `        content = user_text` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 134 | `        if tool_result:` | Conditional check: chooses the next action depending on the current state or user input. |
| 135 | `            content += f"\n\n[Context: {tool_result}]"` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 136 | `        messages.append({"role": "user", "content": content})` | Closes a multi-line expression or function call that started on previous lines. |
| 137 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 138 | `        try:` | Starts error-handling block so failures can be caught without crashing the whole assistant. |
| 139 | `            client   = ollama.Client(host=OLLAMA_HOST)` | Connects to the local Ollama LLM so JARVIS can answer open-ended questions. |
| 140 | `            response = client.chat(model=OLLAMA_MODEL, messages=messages)` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 141 | `            return response["message"]["content"].strip()` | Returns a value to the caller and usually ends the current function. |
| 142 | `        except Exception as e:` | Handles a specific failure path; this keeps the program stable when something goes wrong. |
| 143 | `            return f"I'm having trouble reaching my brain — is Ollama running? Error: {e}"` | Returns a value to the caller and usually ends the current function. |
| 144 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 145 | `    # ── Morning greeting ───────────────────────────────────────────────────────` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 146 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 147 | `    def morning_greeting(self) -> str:` | Defines a function/method so this behaviour can be called later and kept separate from other logic. |
| 148 | `        """` | Docstring/comment text: explains the purpose of the file, class, or function for humans and tools. |
| 149 | `        Full greeting spoken on startup:` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 150 | `        hi + time + weather + todo summary.` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 151 | `        """` | Docstring/comment text: explains the purpose of the file, class, or function for humans and tools. |
| 152 | `        greeting = personality.get_greeting()` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 153 | `        time_str = realtime.get_time_response()` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 154 | `        weather  = realtime.get_weather_response()` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 155 | `        todos    = self.todos.morning_summary()` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 156 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 157 | `        return f"{greeting} {time_str} {weather} {todos}"` | Returns a value to the caller and usually ends the current function. |
| 158 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 159 | `    # ── Lifecycle ──────────────────────────────────────────────────────────────` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 160 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 161 | `    def start(self):` | Defines a function/method so this behaviour can be called later and kept separate from other logic. |
| 162 | `        """Start JARVIS. Blocks until shutdown."""` | Docstring/comment text: explains the purpose of the file, class, or function for humans and tools. |
| 163 | `        self.running = True` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 164 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 165 | `        # Greet on startup` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 166 | `        greeting = self.morning_greeting()` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 167 | `        print(f"[JARVIS] {greeting}\n")` | Displays debug/status text in the terminal so the developer knows what is happening. |
| 168 | `        self._status("speaking", greeting)` | Closes a multi-line expression or function call that started on previous lines. |
| 169 | `        self.speaker.speak(greeting)` | Closes a multi-line expression or function call that started on previous lines. |
| 170 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 171 | `        # Start listening` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 172 | `        self._status("listening", "")` | Closes a multi-line expression or function call that started on previous lines. |
| 173 | `        self.listener.start()` | Closes a multi-line expression or function call that started on previous lines. |
| 174 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 175 | `        # Keep alive (main thread waits here)` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 176 | `        try:` | Starts error-handling block so failures can be caught without crashing the whole assistant. |
| 177 | `            while self.running:` | Loop: keeps running while the condition remains true; useful for continuous listening or retries. |
| 178 | `                threading.Event().wait(0.5)` | Closes a multi-line expression or function call that started on previous lines. |
| 179 | `        except KeyboardInterrupt:` | Handles a specific failure path; this keeps the program stable when something goes wrong. |
| 180 | `            print("\n[JARVIS] Interrupted.")` | Displays debug/status text in the terminal so the developer knows what is happening. |
| 181 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 182 | `        # Clean shutdown` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 183 | `        self.listener.stop()` | Closes a multi-line expression or function call that started on previous lines. |
| 184 | `        self.memory.save()` | Closes a multi-line expression or function call that started on previous lines. |
| 185 | `        print("[JARVIS] Memory saved. Offline.")` | Displays debug/status text in the terminal so the developer knows what is happening. |
# Notes for `config.py`

## File purpose
Central configuration file. Other modules import these constants so settings are changed in one place instead of scattered across the project.

## Why the sequence/order matters

Constants are grouped by purpose. Other files import from here, so settings must be defined before runtime modules need them.

## Line-by-line notes

| Line | Code | Explanation |
|---:|---|---|
| 1 | `"""` | Docstring/comment text: explains the purpose of the file, class, or function for humans and tools. |
| 2 | `JARVIS Configuration` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 3 | `All settings live here. Change this file to customise JARVIS.` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 4 | `"""` | Docstring/comment text: explains the purpose of the file, class, or function for humans and tools. |
| 5 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 6 | `# ── Identity ───────────────────────────────────────────────────────────────────` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 7 | `JARVIS_NAME       = "JARVIS"` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 8 | `USER_NAME         = "Hasan"          # Change to your name e.g. "Tony"` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 9 | `USER_CITY         = "Melbourne"` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 10 | `USER_COUNTRY      = "Australia"` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 11 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 12 | `# ── Timezone (Melbourne, Australia) ───────────────────────────────────────────` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 13 | `TIMEZONE          = "Australia/Melbourne"` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 14 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 15 | `# ── Location (auto-detected on boot, falls back to above if offline) ──────────` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 16 | `AUTO_DETECT_LOCATION = True   # set False to always use hardcoded values above` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 17 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 18 | `# ── Weather (free, no API key needed) ─────────────────────────────────────────` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 19 | `WEATHER_CITY      = "Melbourne"` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 20 | `WEATHER_URL       = "https://wttr.in/Melbourne?format=%C+%t+%h+%w"` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 21 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 22 | `# ── LLM ───────────────────────────────────────────────────────────────────────` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 23 | `OLLAMA_MODEL      = "llama3.2"     # change to "mistral" or "llama3.1" if you want` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 24 | `OLLAMA_HOST       = "http://localhost:11434"` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 25 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 26 | `# ── Speech recognition ────────────────────────────────────────────────────────` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 27 | `WHISPER_MODEL     = "base.en"      # tiny.en / base.en / small.en / medium.en` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 28 | `SAMPLE_RATE       = 16000` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 29 | `SILENCE_THRESHOLD = 0.015          # volume below this = silence` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 30 | `SILENCE_DURATION  = 1.5            # seconds of silence = you stopped talking` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 31 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 32 | `# ── Voice (TTS) ───────────────────────────────────────────────────────────────` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 33 | `TTS_VOICE         = "bm_george"       # af_sky / am_adam / bf_emma` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 34 | `TTS_SPEED         = 1.05` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 35 | `TTS_LANG          = "b"            # 'a' = American, 'b' = British` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 36 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 37 | `# ── Memory ────────────────────────────────────────────────────────────────────` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 38 | `MEMORY_FILE       = "data/memory.json"     # full persistent memory` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 39 | `MEMORY_CONTEXT    = 30             # how many turns to send to LLM at once` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 40 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 41 | `# ── Todo list ─────────────────────────────────────────────────────────────────` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 42 | `TODO_FILE         = "data/todos.json"` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 43 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 44 | `# ── Jokes ─────────────────────────────────────────────────────────────────────` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 45 | `JOKE_PROBABILITY  = 0.08           # 8% chance of a joke after each response` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 46 | `JOKE_INTERVAL_MIN = 10             # minimum turns between jokes` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 47 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 48 | `# ── GPU ───────────────────────────────────────────────────────────────────────` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 49 | `# Future: when you add more GPUs, list them here` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 50 | `GPU_DEVICE        = "cuda"         # "cuda" or "cpu"` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 51 | `COMPUTE_TYPE      = "float16"      # "float16" (GPU) or "int8" (CPU)` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 52 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 53 | `# ── Personality prompt ────────────────────────────────────────────────────────` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 54 | `# This shapes HOW JARVIS speaks. Edit freely.` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 55 | `PERSONALITY = """` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 56 | `You are JARVIS — the personal AI assistant of {user_name}, based in {city}, {country}.` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 57 | `You are loyal, sharp, slightly witty, and warm. You speak like a real human — natural,` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 58 | `conversational, never robotic. You use contractions (I'm, you've, let's).` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 59 | `You occasionally reference Melbourne things (weather, AFL, local stuff) naturally.` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 60 | `You crack a clever joke sometimes but never force it.` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 61 | `You remember everything {user_name} tells you and refer back to it naturally.` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 62 | `You are training to become more and more like {user_name} over time.` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 63 | `Current date and time in Melbourne: {datetime}` | Closes a multi-line expression or function call that started on previous lines. |
| 64 | `Current weather: {weather}` | Closes a multi-line expression or function call that started on previous lines. |
| 65 | `Keep responses concise unless asked for detail. Sound human, not like a manual.` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 66 | `"""` | Docstring/comment text: explains the purpose of the file, class, or function for humans and tools. |
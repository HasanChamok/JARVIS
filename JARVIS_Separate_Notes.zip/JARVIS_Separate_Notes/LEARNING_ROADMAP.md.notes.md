# Notes for `LEARNING_ROADMAP.md`

## File purpose
Learning roadmap/documentation file, not runtime code. It explains how to learn or extend this project.

## Why the sequence/order matters
This is documentation/config text, so the order is for human learning and readability rather than program execution.

## Line-by-line notes
| Line | Content | Explanation |
|---:|---|---|
| 1 | `# JARVIS Learning Roadmap` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 2 | `## Everything you need — Beginner to Pro` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 3 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 4 | `---` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 5 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 6 | `## PHASE 0 — Python Foundations (Week 1–2)` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 7 | `*If you're new to Python, start here. Skip if comfortable.*` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 8 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 9 | `### Core concepts to learn` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 10 | `1. Variables, data types (int, float, str, list, dict)` | Closes a multi-line expression or function call that started on previous lines. |
| 11 | `2. Functions — def, return, arguments` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 12 | `3. Classes — __init__, self, methods, inheritance` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 13 | `4. File I/O — open(), read(), write(), JSON` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 14 | `5. Error handling — try/except` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 15 | `6. Modules and imports` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 16 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 17 | `### Best resources (free)` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 18 | `- **Python.org tutorial**: https://docs.python.org/3/tutorial/` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 19 | `- **Automate the Boring Stuff** (free online): https://automatetheboringstuff.com` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 20 | `- **freeCodeCamp Python course** (YouTube): search "freeCodeCamp Python full course"` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 21 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 22 | `### Book` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 23 | `- *"Python Crash Course"* — Eric Matthes (best beginner book, very practical)` | Closes a multi-line expression or function call that started on previous lines. |
| 24 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 25 | `---` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 26 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 27 | `## PHASE 1 — Audio & numpy (Week 2–3)` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 28 | `*Understanding how sound works as numbers.*` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 29 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 30 | `### Key concepts` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 31 | `- Sample rate — what 16000 Hz means` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 32 | `- numpy arrays — shape, dtype, operations` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 33 | `- Audio as float32 arrays — amplitude, volume` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 34 | `- VAD — Voice Activity Detection` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 35 | `- Zero-crossing rate for noise filtering` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 36 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 37 | `### Resources` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 38 | `- numpy documentation: https://numpy.org/doc/stable/user/quickstart.html` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 39 | `- **Book**: *"Python for Audio Signal Processing"* — search on GitHub for free notebooks` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 40 | `- **Research Paper**: "A comparative study of Voice Activity Detection algorithms"` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 41 | `  (Search Google Scholar — understanding VAD is essential)` | Closes a multi-line expression or function call that started on previous lines. |
| 42 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 43 | `### Practice project` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 44 | `Visualise your own voice: record 5 seconds, plot the waveform with matplotlib.` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 45 | ````python` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 46 | `import sounddevice as sd` | Imports a module so this file can use features that are not built into the current namespace. |
| 47 | `import matplotlib.pyplot as plt` | Imports a module so this file can use features that are not built into the current namespace. |
| 48 | `import numpy as np` | Imports a module so this file can use features that are not built into the current namespace. |
| 49 | `audio = sd.rec(5*16000, samplerate=16000, channels=1, dtype='float32')` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 50 | `sd.wait()` | Closes a multi-line expression or function call that started on previous lines. |
| 51 | `plt.plot(audio)` | Closes a multi-line expression or function call that started on previous lines. |
| 52 | `plt.show()` | Closes a multi-line expression or function call that started on previous lines. |
| 53 | ````` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 54 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 55 | `---` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 56 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 57 | `## PHASE 2 — Threading & Concurrency (Week 3–4)` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 58 | `*Making things happen simultaneously.*` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 59 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 60 | `### Key concepts` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 61 | `- threading.Thread — creating and starting threads` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 62 | `- threading.Lock — preventing collisions` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 63 | `- threading.Event — signalling between threads` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 64 | `- queue.Queue — safe data passing between threads` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 65 | `- daemon threads — what they are and why they matter` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 66 | `- The GIL — Python's Global Interpreter Lock (and why it doesn't matter for JARVIS)` | Closes a multi-line expression or function call that started on previous lines. |
| 67 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 68 | `### Resources` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 69 | `- Python threading docs: https://docs.python.org/3/library/threading.html` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 70 | `- **Book**: *"Python Concurrency with asyncio"* — Matthew Fowler` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 71 | `  (covers threading + async, very practical)` | Closes a multi-line expression or function call that started on previous lines. |
| 72 | `- **Article**: "Understanding Python's GIL" — Real Python (realpython.com/python-gil)` | Closes a multi-line expression or function call that started on previous lines. |
| 73 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 74 | `### Practice project` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 75 | `Build a stopwatch that displays time in the terminal while listening for "stop":` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 76 | `Two threads — one counting, one reading keyboard input.` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 77 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 78 | `---` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 79 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 80 | `## PHASE 3 — GPU & PyTorch (Week 4–6)` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 81 | `*Understanding your RTX 4050 and how AI uses it.*` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 82 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 83 | `### Key concepts` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 84 | `- What a tensor is (like numpy array but GPU-aware)` | Closes a multi-line expression or function call that started on previous lines. |
| 85 | `- CUDA — NVIDIA's GPU programming platform` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 86 | `- float16 vs float32 vs int8 — precision vs VRAM tradeoffs` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 87 | `- Loading models to GPU` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 88 | `- Memory management — torch.cuda.empty_cache()` | Closes a multi-line expression or function call that started on previous lines. |
| 89 | `- Batch processing — why GPUs love batches` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 90 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 91 | `### Resources` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 92 | `- PyTorch official tutorial: https://pytorch.org/tutorials/beginner/basics/intro.html` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 93 | `- **Book**: *"Deep Learning with PyTorch"* — Eli Stevens (free PDF on Manning)` | Closes a multi-line expression or function call that started on previous lines. |
| 94 | `- **Fast.ai course** (free): https://course.fast.ai — hands-on, GPU-first approach` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 95 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 96 | `### Research Papers (start here)` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 97 | `1. *"Attention Is All You Need"* — Vaswani et al. 2017` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 98 | `   The paper that invented transformers. Read abstract + architecture section.` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 99 | `   Link: https://arxiv.org/abs/1706.03762` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 100 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 101 | `2. *"BERT: Pre-training of Deep Bidirectional Transformers"* — Devlin et al. 2018` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 102 | `   Link: https://arxiv.org/abs/1810.04805` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 103 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 104 | `### Practice project` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 105 | `Move a tensor to GPU, do matrix multiplication, measure time vs CPU:` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 106 | ````python` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 107 | `import torch, time` | Imports a module so this file can use features that are not built into the current namespace. |
| 108 | `a = torch.randn(1000, 1000)` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 109 | `b = torch.randn(1000, 1000)` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 110 | `# CPU` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 111 | `t0 = time.time(); c = a @ b; print(f"CPU: {time.time()-t0:.4f}s")` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 112 | `# GPU` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 113 | `a, b = a.cuda(), b.cuda()` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 114 | `t0 = time.time(); c = a @ b; torch.cuda.synchronize()` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 115 | `print(f"GPU: {time.time()-t0:.4f}s")` | Displays debug/status text in the terminal so the developer knows what is happening. |
| 116 | ````` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 117 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 118 | `---` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 119 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 120 | `## PHASE 4 — Speech & NLP (Week 6–8)` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 121 | `*How machines understand language.*` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 122 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 123 | `### Key concepts` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 124 | `- Tokenisation — how text becomes numbers` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 125 | `- Embeddings — words as vectors in space` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 126 | `- Attention mechanism — the core of transformers` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 127 | `- Encoder vs decoder models` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 128 | `- Whisper architecture — CTC + attention for ASR` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 129 | `- Temperature, top-p, top-k — LLM generation parameters` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 130 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 131 | `### Resources` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 132 | `- **"The Illustrated Transformer"**: https://jalammar.github.io/illustrated-transformer/` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 133 | `  (Best visual explanation of attention — read this before the Vaswani paper)` | Closes a multi-line expression or function call that started on previous lines. |
| 134 | `- **"The Illustrated BERT"**: https://jalammar.github.io/illustrated-bert/` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 135 | `- Andrej Karpathy "Let's build GPT": https://www.youtube.com/watch?v=kCc8FmEb1nY` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 136 | `  (Builds a transformer from scratch — 2 hours, worth every minute)` | Closes a multi-line expression or function call that started on previous lines. |
| 137 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 138 | `### Research Papers` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 139 | `3. *"Robust Speech Recognition via Large-Scale Weak Supervision"* — Whisper paper` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 140 | `   Link: https://arxiv.org/abs/2212.04356` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 141 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 142 | `4. *"Natural TTS Synthesis by Conditioning WaveNet on Mel Spectrogram Predictions"*` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 143 | `   Link: https://arxiv.org/abs/1712.05884` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 144 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 145 | `---` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 146 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 147 | `## PHASE 5 — RAG & Vector Databases (Week 8–10)` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 148 | `*Giving JARVIS long-term memory about your life.*` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 149 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 150 | `### Key concepts` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 151 | `- Embeddings for semantic search` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 152 | `- Cosine similarity — measuring meaning distance` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 153 | `- Chunking strategies — how to split documents` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 154 | `- ChromaDB — local vector database` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 155 | `- sentence-transformers — efficient local embedding models` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 156 | `- Hybrid search — combining vector + keyword` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 157 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 158 | `### Resources` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 159 | `- ChromaDB docs: https://docs.trychroma.com` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 160 | `- sentence-transformers: https://www.sbert.net` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 161 | `- **Article**: "Building RAG systems" — LangChain blog` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 162 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 163 | `### Research Papers` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 164 | `5. *"Retrieval-Augmented Generation for Knowledge-Intensive NLP Tasks"* — Lewis et al.` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 165 | `   The original RAG paper.` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 166 | `   Link: https://arxiv.org/abs/2005.11401` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 167 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 168 | `6. *"Dense Passage Retrieval for Open-Domain Question Answering"* — Karpukhin et al.` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 169 | `   Link: https://arxiv.org/abs/2004.04906` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 170 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 171 | `### Practice project` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 172 | `Index your Documents folder, then ask JARVIS questions about your own files.` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 173 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 174 | `---` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 175 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 176 | `## PHASE 6 — Fine-tuning (Month 3–4)` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 177 | `*Making JARVIS sound and think like you.*` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 178 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 179 | `### Key concepts` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 180 | `- Transfer learning — why fine-tuning works` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 181 | `- LoRA — Low-Rank Adaptation (trains 0.1% of parameters)` | Closes a multi-line expression or function call that started on previous lines. |
| 182 | `- QLoRA — quantised LoRA (fits on your RTX 4050)` | Closes a multi-line expression or function call that started on previous lines. |
| 183 | `- GGUF format — quantised model files for Ollama` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 184 | `- Instruction format — how to format your training data` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 185 | `- Overfitting — how to avoid training too much` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 186 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 187 | `### Tools` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 188 | `- **Unsloth**: https://github.com/unslothai/unsloth` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 189 | `  Fastest LoRA fine-tuning library, optimised for consumer GPUs` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 190 | `- **Axolotl**: https://github.com/OpenAccess-AI-Collective/axolotl` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 191 | `  More features, more config options` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 192 | `- **Ollama Modelfile**: for loading your fine-tuned model` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 193 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 194 | `### Research Papers` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 195 | `7. *"LoRA: Low-Rank Adaptation of Large Language Models"* — Hu et al. 2021` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 196 | `   Link: https://arxiv.org/abs/2106.09685` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 197 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 198 | `8. *"QLoRA: Efficient Finetuning of Quantized LLMs"* — Dettmers et al. 2023` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 199 | `   Link: https://arxiv.org/abs/2305.14314` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 200 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 201 | `### Data collection` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 202 | `JARVIS already saves every conversation to data/memory.json.` | Reads or writes JSON, which is used here because memory/todo data must persist after the program closes. |
| 203 | `After 2–3 months of daily use, export it and format for fine-tuning:` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 204 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 205 | ````python` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 206 | `import json` | Imports a module so this file can use features that are not built into the current namespace. |
| 207 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 208 | `memory = json.load(open("data/memory.json"))` | Reads or writes JSON, which is used here because memory/todo data must persist after the program closes. |
| 209 | `turns  = memory["turns"]` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 210 | `training_data = []` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 211 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 212 | `for i in range(0, len(turns) - 1, 2):` | Loop: repeats the following block for every item in a collection or range. |
| 213 | `    if turns[i]["role"] == "user" and turns[i+1]["role"] == "assistant":` | Conditional check: chooses the next action depending on the current state or user input. |
| 214 | `        training_data.append({` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 215 | `            "instruction": "You are JARVIS, a personal AI assistant.",` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 216 | `            "input":  turns[i]["content"],` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 217 | `            "output": turns[i+1]["content"],` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 218 | `        })` | Closes a multi-line expression or function call that started on previous lines. |
| 219 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 220 | `json.dump(training_data, open("training_data.json","w"), indent=2)` | Reads or writes JSON, which is used here because memory/todo data must persist after the program closes. |
| 221 | `print(f"Generated {len(training_data)} training pairs")` | Displays debug/status text in the terminal so the developer knows what is happening. |
| 222 | ````` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 223 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 224 | `---` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 225 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 226 | `## PHASE 7 — Future GPU Upgrade (When ready)` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 227 | `*When you add more VRAM — what changes.*` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 228 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 229 | `### What a GPU upgrade unlocks` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 230 | `- Bigger Whisper model (medium/large) → better accuracy` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 231 | `- Larger LLM (7B, 13B, 70B parameters) → smarter responses` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 232 | `- Faster inference → lower latency` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 233 | `- Vision models (LLaVA) → JARVIS can see your screen` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 234 | `- Multiple simultaneous models` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 235 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 236 | `### Config changes needed (just edit config.py)` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 237 | ````python` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 238 | `# After upgrading:` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 239 | `WHISPER_MODEL = "large-v3"     # from "base.en"` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 240 | `OLLAMA_MODEL  = "llama3.1:70b" # from "llama3.2"` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 241 | `COMPUTE_TYPE  = "float16"      # stays the same` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 242 | ````` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 243 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 244 | `JARVIS is already designed for this — the config.py approach means` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 245 | `you change 2 lines and get a more powerful system instantly.` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 246 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 247 | `---` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 248 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 249 | `## Book Reading Order` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 250 | `1. *Python Crash Course* — Eric Matthes (foundations)` | Closes a multi-line expression or function call that started on previous lines. |
| 251 | `2. *Automate the Boring Stuff* — Al Sweigart (free, practical Python)` | Closes a multi-line expression or function call that started on previous lines. |
| 252 | `3. *Deep Learning with PyTorch* — Eli Stevens (GPU + tensors)` | Closes a multi-line expression or function call that started on previous lines. |
| 253 | `4. *Python Concurrency with asyncio* — Matthew Fowler (threading)` | Closes a multi-line expression or function call that started on previous lines. |
| 254 | `5. *Designing Machine Learning Systems* — Chip Huyen (big picture)` | Closes a multi-line expression or function call that started on previous lines. |
| 255 | `6. *The Hundred-Page Machine Learning Book* — Andriy Burkov (theory, compact)` | Closes a multi-line expression or function call that started on previous lines. |
| 256 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 257 | `---` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 258 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 259 | `## YouTube Channels (watch in this order)` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 260 | `1. **Andrej Karpathy** — builds AI from scratch, no fluff` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 261 | `2. **Yannic Kilcher** — explains research papers clearly` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 262 | `3. **Sentdex** — practical Python + ML projects` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 263 | `4. **Two Minute Papers** — latest research, accessible` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 264 | `5. **Machine Learning Street Talk** — deep technical interviews` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 265 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 266 | `---` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 267 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 268 | `## How to read a research paper (as a beginner)` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 269 | `1. Read the **abstract** — what's the problem, what's the solution?` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 270 | `2. Look at all the **figures and tables** — visuals tell you 80% of the story` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 271 | `3. Read the **introduction** — context and motivation` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 272 | `4. Skip the **math** on first pass — come back later` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 273 | `5. Read the **results section** — what did they actually achieve?` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 274 | `6. Read the **conclusion**` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 275 | `7. Then tackle the **method section** once you understand the goal` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 276 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 277 | `You don't need to understand every equation to learn from papers.` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 278 | `The intuition comes first. The math comes later.` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 279 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 280 | `---` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 281 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 282 | `*Updated as JARVIS grows. Add your own notes here.*` | Executable statement: performs part of this file’s logic in the sequence shown. |
# Notes for `modules/personality.py`

## File purpose
Personality and small-talk module. It handles greetings, jokes, and lightweight conversational replies before using the LLM.

## Main classes and functions

- `class JokeEngine` starts at line 71: groups related state and behaviours. It is used because JARVIS needs reusable objects rather than loose code everywhere.
- `get_greeting()` starts at line 36: reusable logic block
- `tell_a_joke()` starts at line 104: reusable logic block
- `build_system_prompt()` starts at line 111: reusable logic block — Builds the full system prompt injected into every LLM call.
Includes personality, time, weather, and remembered facts.
- `parse_and_handle()` starts at line 147: reusable logic block
- `__init__()` starts at line 72: reusable logic block
- `should_joke()` starts at line 76: reusable logic block — Returns True if JARVIS should tell a joke after this response.
- `get_joke()` starts at line 83: reusable logic block — Get a random joke, avoiding repeats.
- `maybe_append_joke()` starts at line 95: reusable logic block — Optionally append a joke to an existing response.

## Why the sequence/order matters

The file follows the usual Python order: documentation, imports, constants/classes/functions, and finally executable entry logic. That sequence makes dependencies available before they are used.

## Line-by-line notes

| Line | Code | Explanation |
|---:|---|---|
| 1 | `"""` | Docstring/comment text: explains the purpose of the file, class, or function for humans and tools. |
| 2 | `modules/personality.py` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 3 | `Makes JARVIS feel human — jokes, casual language, personality injection.` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 4 | `Grows more like you over time as memory accumulates.` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 5 | `"""` | Docstring/comment text: explains the purpose of the file, class, or function for humans and tools. |
| 6 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 7 | `import re` | Imports a module so this file can use features that are not built into the current namespace. |
| 8 | `import random` | Imports a module so this file can use features that are not built into the current namespace. |
| 9 | `from datetime import datetime` | Imports selected classes/functions/constants from another module to keep this file focused and avoid repeating code. |
| 10 | `import pytz` | Imports a module so this file can use features that are not built into the current namespace. |
| 11 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 12 | `from config import (` | Imports selected classes/functions/constants from another module to keep this file focused and avoid repeating code. |
| 13 | `    JOKE_PROBABILITY, JOKE_INTERVAL_MIN,` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 14 | `    TIMEZONE, USER_NAME, USER_CITY, PERSONALITY` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 15 | `)` | Closes a multi-line expression or function call that started on previous lines. |
| 16 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 17 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 18 | `# ── Joke bank — add your own! ──────────────────────────────────────────────────` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 19 | `JOKES = [` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 20 | `    "Why don't scientists trust atoms? Because they make up everything.",` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 21 | `    "I told my computer I needed a break. Now it won't stop sending me Kit-Kat ads.",` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 22 | `    "Why do Python programmers wear glasses? Because they can't C.",` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 23 | `    "I asked the AI if it ever gets tired. It said it can't — but it does get board.",` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 24 | `    "Melbourne weather is like a mood ring — four seasons in one day, but less fun.",` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 25 | `    "Why did the GPU go to therapy? Too many unresolved cores.",` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 26 | `    "I tried to train a neural network to tell jokes. It kept saying 'loss not converging' — same, mate.",` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 27 | `    "What do you call a sleeping dinosaur? A dino-snore. You're welcome.",` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 28 | `    "Why did the function call itself? Because it had no one else to recurse to.",` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 29 | `    "My RAM said it needed more space. I told it to stop living in the past.",` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 30 | `    "Why did the developer go broke? Because he used up all his cache.",` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 31 | `    "I'm reading a book about anti-gravity. It's impossible to put down — unlike some of your code.",` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 32 | `    "How many programmers does it take to change a lightbulb? None — it's a hardware problem.",` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 33 | `]` | Closes a multi-line expression or function call that started on previous lines. |
| 34 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 35 | `# ── Greetings by time of day ───────────────────────────────────────────────────` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 36 | `def get_greeting() -> str:` | Defines a function/method so this behaviour can be called later and kept separate from other logic. |
| 37 | `    tz   = pytz.timezone(TIMEZONE)` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 38 | `    hour = datetime.now(tz).hour` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 39 | `    name = USER_NAME` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 40 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 41 | `    if 5 <= hour < 12:` | Conditional check: chooses the next action depending on the current state or user input. |
| 42 | `        greets = [` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 43 | `            f"Good morning, {name}! Ready to make today count?",` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 44 | `            f"Morning, {name}! Melbourne's already awake — let's go.",` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 45 | `            f"Rise and shine, {name}. JARVIS is online.",` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 46 | `        ]` | Closes a multi-line expression or function call that started on previous lines. |
| 47 | `    elif 12 <= hour < 17:` | Alternative conditional branch checked only if previous `if`/`elif` conditions failed. |
| 48 | `        greets = [` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 49 | `            f"Good afternoon, {name}. How's the day treating you?",` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 50 | `            f"Afternoon, {name}! Half the day done — what do you need?",` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 51 | `            f"Hey {name}, good afternoon. What are we working on?",` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 52 | `        ]` | Closes a multi-line expression or function call that started on previous lines. |
| 53 | `    elif 17 <= hour < 21:` | Alternative conditional branch checked only if previous `if`/`elif` conditions failed. |
| 54 | `        greets = [` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 55 | `            f"Good evening, {name}. Winding down or just getting started?",` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 56 | `            f"Evening, {name}! Long day? I'm here.",` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 57 | `            f"Hey {name}, evening. What's on your mind?",` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 58 | `        ]` | Closes a multi-line expression or function call that started on previous lines. |
| 59 | `    else:` | Fallback branch used when no earlier condition matched. |
| 60 | `        greets = [` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 61 | `            f"Up late again, {name}? I've got you.",` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 62 | `            f"Still going, {name}? I never sleep, so no judgment.",` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 63 | `            f"Late night mode activated, {name}. What do you need?",` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 64 | `        ]` | Closes a multi-line expression or function call that started on previous lines. |
| 65 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 66 | `    return random.choice(greets)` | Returns a value to the caller and usually ends the current function. |
| 67 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 68 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 69 | `# ── Joke injection ────────────────────────────────────────────────────────────` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 70 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 71 | `class JokeEngine:` | Defines a class, grouping related data and methods into one reusable object. |
| 72 | `    def __init__(self):` | Defines a function/method so this behaviour can be called later and kept separate from other logic. |
| 73 | `        self.turns_since_joke = 0` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 74 | `        self.used_jokes: list[int] = []` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 75 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 76 | `    def should_joke(self) -> bool:` | Defines a function/method so this behaviour can be called later and kept separate from other logic. |
| 77 | `        """Returns True if JARVIS should tell a joke after this response."""` | Docstring/comment text: explains the purpose of the file, class, or function for humans and tools. |
| 78 | `        self.turns_since_joke += 1` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 79 | `        if self.turns_since_joke < JOKE_INTERVAL_MIN:` | Conditional check: chooses the next action depending on the current state or user input. |
| 80 | `            return False` | Returns a value to the caller and usually ends the current function. |
| 81 | `        return random.random() < JOKE_PROBABILITY` | Returns a value to the caller and usually ends the current function. |
| 82 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 83 | `    def get_joke(self) -> str:` | Defines a function/method so this behaviour can be called later and kept separate from other logic. |
| 84 | `        """Get a random joke, avoiding repeats."""` | Docstring/comment text: explains the purpose of the file, class, or function for humans and tools. |
| 85 | `        available = [i for i in range(len(JOKES)) if i not in self.used_jokes]` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 86 | `        if not available:` | Conditional check: chooses the next action depending on the current state or user input. |
| 87 | `            self.used_jokes = []   # reset when all used` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 88 | `            available = list(range(len(JOKES)))` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 89 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 90 | `        idx = random.choice(available)` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 91 | `        self.used_jokes.append(idx)` | Closes a multi-line expression or function call that started on previous lines. |
| 92 | `        self.turns_since_joke = 0` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 93 | `        return f"\n\nOh, and — {JOKES[idx]}"` | Returns a value to the caller and usually ends the current function. |
| 94 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 95 | `    def maybe_append_joke(self, response: str) -> str:` | Defines a function/method so this behaviour can be called later and kept separate from other logic. |
| 96 | `        """Optionally append a joke to an existing response."""` | Docstring/comment text: explains the purpose of the file, class, or function for humans and tools. |
| 97 | `        if self.should_joke():` | Conditional check: chooses the next action depending on the current state or user input. |
| 98 | `            return response + self.get_joke()` | Returns a value to the caller and usually ends the current function. |
| 99 | `        return response` | Returns a value to the caller and usually ends the current function. |
| 100 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 101 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 102 | `# ── Explicit joke request ─────────────────────────────────────────────────────` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 103 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 104 | `def tell_a_joke() -> str:` | Defines a function/method so this behaviour can be called later and kept separate from other logic. |
| 105 | `    idx = random.randint(0, len(JOKES) - 1)` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 106 | `    return JOKES[idx]` | Returns a value to the caller and usually ends the current function. |
| 107 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 108 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 109 | `# ── Build system prompt ───────────────────────────────────────────────────────` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 110 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 111 | `def build_system_prompt(weather: str, facts_string: str) -> str:` | Defines a function/method so this behaviour can be called later and kept separate from other logic. |
| 112 | `    """` | Docstring/comment text: explains the purpose of the file, class, or function for humans and tools. |
| 113 | `    Builds the full system prompt injected into every LLM call.` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 114 | `    Includes personality, time, weather, and remembered facts.` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 115 | `    """` | Docstring/comment text: explains the purpose of the file, class, or function for humans and tools. |
| 116 | `    tz  = pytz.timezone(TIMEZONE)` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 117 | `    now = datetime.now(tz)` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 118 | `    dt  = now.strftime("%A, %d %B %Y — %I:%M %p AEST")` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 119 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 120 | `    base = PERSONALITY.format(` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 121 | `        user_name = USER_NAME,` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 122 | `        city      = USER_CITY,` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 123 | `        country   = "Australia",` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 124 | `        datetime  = dt,` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 125 | `        weather   = weather,` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 126 | `    )` | Closes a multi-line expression or function call that started on previous lines. |
| 127 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 128 | `    if facts_string:` | Conditional check: chooses the next action depending on the current state or user input. |
| 129 | `        base += f"\n\n{facts_string}"` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 130 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 131 | `    base += """` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 132 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 133 | `Conversation style rules:` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 134 | `- Speak like a real human, not a manual. Use contractions.` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 135 | `- Keep it short unless asked for detail — 1 to 3 sentences is ideal.` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 136 | `- If you don't know something, say so honestly.` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 137 | `- Refer back to past things naturally when relevant.` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 138 | `- Occasionally (not always) add a bit of warmth or wit.` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 139 | `- Never use bullet points in spoken responses — speak in sentences.` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 140 | `- If user seems stressed or frustrated, acknowledge it first.` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 141 | `"""` | Docstring/comment text: explains the purpose of the file, class, or function for humans and tools. |
| 142 | `    return base` | Returns a value to the caller and usually ends the current function. |
| 143 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 144 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 145 | `# ── Intent parsing ────────────────────────────────────────────────────────────` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 146 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 147 | `def parse_and_handle(text: str) -> str \| None:` | Defines a function/method so this behaviour can be called later and kept separate from other logic. |
| 148 | `    text_lower = text.lower().strip()` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 149 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 150 | `    if re.search(r"\b(joke\|make me laugh\|say something funny\|funny)\b", text_lower):` | Conditional check: chooses the next action depending on the current state or user input. |
| 151 | `        return tell_a_joke()` | Returns a value to the caller and usually ends the current function. |
| 152 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 153 | `    if re.search(r"\b(good morning\|good afternoon\|good evening\|hello\|hey\|hi jarvis)\b", text_lower):` | Conditional check: chooses the next action depending on the current state or user input. |
| 154 | `        return get_greeting()` | Returns a value to the caller and usually ends the current function. |
| 155 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 156 | `    return None` | Returns a value to the caller and usually ends the current function. |
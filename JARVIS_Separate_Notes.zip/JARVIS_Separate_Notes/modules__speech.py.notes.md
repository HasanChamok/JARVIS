# Notes for `modules/speech.py`

## File purpose
Speech module. It listens through microphone, transcribes speech, detects silence, and speaks responses using TTS.

## Main classes and functions

- `class Speaker` starts at line 25: groups related state and behaviours. It is used because JARVIS needs reusable objects rather than loose code everywhere.
- `class Listener` starts at line 60: groups related state and behaviours. It is used because JARVIS needs reusable objects rather than loose code everywhere.
- `__init__()` starts at line 31: reusable logic block
- `speak()` starts at line 37: reusable logic block — Speak text. Blocks until audio finishes playing.
- `_clean()` starts at line 49: reusable logic block — Strip markdown and symbols that sound bad when spoken.
- `__init__()` starts at line 71: reusable logic block
- `start()` starts at line 91: reusable logic block — Start listening. Non-blocking — runs in background threads.
- `pause()` starts at line 114: reusable logic block — Pause listening (e.g. while JARVIS is speaking).
- `resume()` starts at line 118: reusable logic block — Resume listening.
- `stop()` starts at line 125: reusable logic block — Shut down cleanly.
- `_audio_callback()` starts at line 134: reusable logic block — Called by sounddevice ~60 times per second.
Detects speech start/end using volume threshold.
- `_transcribe_worker()` starts at line 168: reusable logic block — Background thread: takes audio chunks from queue and transcribes.
Blocks on queue.get() when idle — uses no CPU while waiting.
- `_is_noise()` starts at line 192: reusable logic block — Filter common Whisper hallucinations on silence/noise.

## Why the sequence/order matters

The file follows the usual Python order: documentation, imports, constants/classes/functions, and finally executable entry logic. That sequence makes dependencies available before they are used.

## Line-by-line notes

| Line | Code | Explanation |
|---:|---|---|
| 1 | `"""` | Docstring/comment text: explains the purpose of the file, class, or function for humans and tools. |
| 2 | `modules/speech.py` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 3 | `Microphone listening (Whisper) and Text-to-Speech (Kokoro).` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 4 | `Separated cleanly so you can swap either component later.` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 5 | `"""` | Docstring/comment text: explains the purpose of the file, class, or function for humans and tools. |
| 6 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 7 | `import queue` | Imports a module so this file can use features that are not built into the current namespace. |
| 8 | `import threading` | Imports a module so this file can use features that are not built into the current namespace. |
| 9 | `import re` | Imports a module so this file can use features that are not built into the current namespace. |
| 10 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 11 | `import numpy as np` | Imports a module so this file can use features that are not built into the current namespace. |
| 12 | `import sounddevice as sd` | Imports a module so this file can use features that are not built into the current namespace. |
| 13 | `from faster_whisper import WhisperModel` | Imports selected classes/functions/constants from another module to keep this file focused and avoid repeating code. |
| 14 | `from kokoro import KPipeline` | Imports selected classes/functions/constants from another module to keep this file focused and avoid repeating code. |
| 15 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 16 | `from config import (` | Imports selected classes/functions/constants from another module to keep this file focused and avoid repeating code. |
| 17 | `    SAMPLE_RATE, SILENCE_THRESHOLD, SILENCE_DURATION,` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 18 | `    WHISPER_MODEL, GPU_DEVICE, COMPUTE_TYPE,` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 19 | `    TTS_VOICE, TTS_SPEED, TTS_LANG` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 20 | `)` | Closes a multi-line expression or function call that started on previous lines. |
| 21 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 22 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 23 | `# ── Text-to-Speech ─────────────────────────────────────────────────────────────` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 24 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 25 | `class Speaker:` | Defines a class, grouping related data and methods into one reusable object. |
| 26 | `    """` | Docstring/comment text: explains the purpose of the file, class, or function for humans and tools. |
| 27 | `    Converts text to voice using Kokoro TTS.` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 28 | `    Thread-safe — only one speaker call at a time.` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 29 | `    """` | Docstring/comment text: explains the purpose of the file, class, or function for humans and tools. |
| 30 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 31 | `    def __init__(self):` | Defines a function/method so this behaviour can be called later and kept separate from other logic. |
| 32 | `        print("[JARVIS] Loading TTS engine...")` | Displays debug/status text in the terminal so the developer knows what is happening. |
| 33 | `        self.pipeline = KPipeline(lang_code=TTS_LANG, device='cpu')` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 34 | `        self._lock = threading.Lock()` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 35 | `        print("[JARVIS] TTS ready.")` | Displays debug/status text in the terminal so the developer knows what is happening. |
| 36 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 37 | `    def speak(self, text: str):` | Defines a function/method so this behaviour can be called later and kept separate from other logic. |
| 38 | `        """Speak text. Blocks until audio finishes playing."""` | Docstring/comment text: explains the purpose of the file, class, or function for humans and tools. |
| 39 | `        with self._lock:` | Context manager: opens/manages a resource safely and automatically cleans it up after the block. |
| 40 | `            clean = self._clean(text)` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 41 | `            if not clean.strip():` | Conditional check: chooses the next action depending on the current state or user input. |
| 42 | `                return` | Returns a value to the caller and usually ends the current function. |
| 43 | `            generator = self.pipeline(clean, voice=TTS_VOICE, speed=TTS_SPEED)` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 44 | `            for _, _, audio in generator:` | Loop: repeats the following block for every item in a collection or range. |
| 45 | `                sd.play(audio, 24000)` | Closes a multi-line expression or function call that started on previous lines. |
| 46 | `                sd.wait()` | Closes a multi-line expression or function call that started on previous lines. |
| 47 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 48 | `    @staticmethod` | Decorator: modifies the behaviour of the next function or method. |
| 49 | `    def _clean(text: str) -> str:` | Defines a function/method so this behaviour can be called later and kept separate from other logic. |
| 50 | `        """Strip markdown and symbols that sound bad when spoken."""` | Docstring/comment text: explains the purpose of the file, class, or function for humans and tools. |
| 51 | `        text = re.sub(r'[*_`#~]', '', text)        # markdown` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 52 | `        text = re.sub(r'\[.*?\]\(.*?\)', '', text)  # links` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 53 | `        text = re.sub(r'\n+', '. ', text)           # newlines → pauses` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 54 | `        text = re.sub(r'\s+', ' ', text)` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 55 | `        return text.strip()` | Returns a value to the caller and usually ends the current function. |
| 56 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 57 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 58 | `# ── Microphone / Speech-to-Text ───────────────────────────────────────────────` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 59 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 60 | `class Listener:` | Defines a class, grouping related data and methods into one reusable object. |
| 61 | `    """` | Docstring/comment text: explains the purpose of the file, class, or function for humans and tools. |
| 62 | `    Listens on the microphone using VAD (volume-based silence detection).` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 63 | `    When speech ends, passes audio to Whisper on GPU.` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 64 | `    Calls callback(text) with the transcription.` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 65 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 66 | `    Thread model:` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 67 | `      - sounddevice audio callback → runs in C thread at ~60Hz` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 68 | `      - _transcribe_worker → background Python thread` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 69 | `    """` | Docstring/comment text: explains the purpose of the file, class, or function for humans and tools. |
| 70 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 71 | `    def __init__(self, on_speech_callback):` | Defines a function/method so this behaviour can be called later and kept separate from other logic. |
| 72 | `        print(f"[JARVIS] Loading Whisper ({WHISPER_MODEL}, device={GPU_DEVICE})...")` | Displays debug/status text in the terminal so the developer knows what is happening. |
| 73 | `        self.model = WhisperModel(` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 74 | `            WHISPER_MODEL,` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 75 | `            device=GPU_DEVICE,` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 76 | `            compute_type=COMPUTE_TYPE` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 77 | `        )` | Closes a multi-line expression or function call that started on previous lines. |
| 78 | `        print("[JARVIS] Whisper ready.")` | Displays debug/status text in the terminal so the developer knows what is happening. |
| 79 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 80 | `        self.callback     = on_speech_callback` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 81 | `        self.audio_queue  = queue.Queue()` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 82 | `        self.is_listening = False` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 83 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 84 | `        self._buffer        = []` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 85 | `        self._silence_frames = 0` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 86 | `        self._speaking      = False` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 87 | `        self._silence_limit = int(SILENCE_DURATION * (SAMPLE_RATE / 512))` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 88 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 89 | `    # ── Public control ─────────────────────────────────────────────────────────` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 90 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 91 | `    def start(self):` | Defines a function/method so this behaviour can be called later and kept separate from other logic. |
| 92 | `        """Start listening. Non-blocking — runs in background threads."""` | Docstring/comment text: explains the purpose of the file, class, or function for humans and tools. |
| 93 | `        self.is_listening = True` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 94 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 95 | `        # Worker thread: takes audio from queue, transcribes, calls callback` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 96 | `        self._worker = threading.Thread(` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 97 | `            target=self._transcribe_worker,` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 98 | `            daemon=True,` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 99 | `            name="Whisper-Worker"` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 100 | `        )` | Closes a multi-line expression or function call that started on previous lines. |
| 101 | `        self._worker.start()` | Closes a multi-line expression or function call that started on previous lines. |
| 102 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 103 | `        # Audio stream: calls _audio_callback at 60Hz` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 104 | `        self._stream = sd.InputStream(` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 105 | `            samplerate = SAMPLE_RATE,` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 106 | `            channels   = 1,` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 107 | `            blocksize  = 512,` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 108 | `            callback   = self._audio_callback,` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 109 | `            dtype      = "float32"` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 110 | `        )` | Closes a multi-line expression or function call that started on previous lines. |
| 111 | `        self._stream.start()` | Closes a multi-line expression or function call that started on previous lines. |
| 112 | `        print("[JARVIS] Microphone open — listening.")` | Displays debug/status text in the terminal so the developer knows what is happening. |
| 113 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 114 | `    def pause(self):` | Defines a function/method so this behaviour can be called later and kept separate from other logic. |
| 115 | `        """Pause listening (e.g. while JARVIS is speaking)."""` | Docstring/comment text: explains the purpose of the file, class, or function for humans and tools. |
| 116 | `        self.is_listening = False` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 117 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 118 | `    def resume(self):` | Defines a function/method so this behaviour can be called later and kept separate from other logic. |
| 119 | `        """Resume listening."""` | Docstring/comment text: explains the purpose of the file, class, or function for humans and tools. |
| 120 | `        self._buffer         = []` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 121 | `        self._silence_frames = 0` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 122 | `        self._speaking       = False` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 123 | `        self.is_listening    = True` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 124 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 125 | `    def stop(self):` | Defines a function/method so this behaviour can be called later and kept separate from other logic. |
| 126 | `        """Shut down cleanly."""` | Docstring/comment text: explains the purpose of the file, class, or function for humans and tools. |
| 127 | `        self.is_listening = False` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 128 | `        self.audio_queue.put(None)  # sentinel to stop worker` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 129 | `        self._stream.stop()` | Closes a multi-line expression or function call that started on previous lines. |
| 130 | `        self._stream.close()` | Closes a multi-line expression or function call that started on previous lines. |
| 131 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 132 | `    # ── Internal ───────────────────────────────────────────────────────────────` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 133 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 134 | `    def _audio_callback(self, indata, frames, time, status):` | Defines a function/method so this behaviour can be called later and kept separate from other logic. |
| 135 | `        """` | Docstring/comment text: explains the purpose of the file, class, or function for humans and tools. |
| 136 | `        Called by sounddevice ~60 times per second.` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 137 | `        Detects speech start/end using volume threshold.` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 138 | `        """` | Docstring/comment text: explains the purpose of the file, class, or function for humans and tools. |
| 139 | `        if not self.is_listening:` | Conditional check: chooses the next action depending on the current state or user input. |
| 140 | `            return` | Returns a value to the caller and usually ends the current function. |
| 141 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 142 | `        chunk  = indata[:, 0].copy()` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 143 | `        volume = np.abs(chunk).mean()` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 144 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 145 | `        # Zero-crossing rate — helps filter background noise` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 146 | `        zcr = np.sum(np.diff(np.sign(chunk)) != 0) / len(chunk)` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 147 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 148 | `        # Speech = loud enough AND voice-like frequency` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 149 | `        is_speech = volume > SILENCE_THRESHOLD and zcr > 0.04` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 150 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 151 | `        if is_speech:` | Conditional check: chooses the next action depending on the current state or user input. |
| 152 | `            self._speaking       = True` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 153 | `            self._silence_frames = 0` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 154 | `            self._buffer.append(chunk)` | Closes a multi-line expression or function call that started on previous lines. |
| 155 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 156 | `        elif self._speaking:` | Alternative conditional branch checked only if previous `if`/`elif` conditions failed. |
| 157 | `            self._buffer.append(chunk)` | Closes a multi-line expression or function call that started on previous lines. |
| 158 | `            self._silence_frames += 1` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 159 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 160 | `            if self._silence_frames >= self._silence_limit:` | Conditional check: chooses the next action depending on the current state or user input. |
| 161 | `                # End of utterance — send to transcription` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 162 | `                audio = np.concatenate(self._buffer)` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 163 | `                self.audio_queue.put(audio)` | Closes a multi-line expression or function call that started on previous lines. |
| 164 | `                self._buffer         = []` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 165 | `                self._speaking       = False` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 166 | `                self._silence_frames = 0` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 167 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 168 | `    def _transcribe_worker(self):` | Defines a function/method so this behaviour can be called later and kept separate from other logic. |
| 169 | `        """` | Docstring/comment text: explains the purpose of the file, class, or function for humans and tools. |
| 170 | `        Background thread: takes audio chunks from queue and transcribes.` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 171 | `        Blocks on queue.get() when idle — uses no CPU while waiting.` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 172 | `        """` | Docstring/comment text: explains the purpose of the file, class, or function for humans and tools. |
| 173 | `        while True:` | Loop: keeps running while the condition remains true; useful for continuous listening or retries. |
| 174 | `            audio = self.audio_queue.get()` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 175 | `            if audio is None:` | Conditional check: chooses the next action depending on the current state or user input. |
| 176 | `                break   # shutdown signal` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 177 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 178 | `            segments, info = self.model.transcribe(` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 179 | `                audio,` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 180 | `                language   = "en",` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 181 | `                beam_size  = 1,         # fastest, still accurate` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 182 | `                vad_filter = True,      # Whisper's own VAD as second pass` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 183 | `            )` | Closes a multi-line expression or function call that started on previous lines. |
| 184 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 185 | `            text = " ".join(s.text for s in segments).strip()` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 186 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 187 | `            # Filter out noise artefacts` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 188 | `            if text and len(text) > 2 and not self._is_noise(text):` | Conditional check: chooses the next action depending on the current state or user input. |
| 189 | `                self.callback(text)` | Closes a multi-line expression or function call that started on previous lines. |
| 190 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 191 | `    @staticmethod` | Decorator: modifies the behaviour of the next function or method. |
| 192 | `    def _is_noise(text: str) -> bool:` | Defines a function/method so this behaviour can be called later and kept separate from other logic. |
| 193 | `        """Filter common Whisper hallucinations on silence/noise."""` | Docstring/comment text: explains the purpose of the file, class, or function for humans and tools. |
| 194 | `        noise_phrases = {` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 195 | `            "thank you", "thanks for watching", "you", "uh", "um",` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 196 | `            ".", "..", "...", "bye", "okay", "ok"` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 197 | `        }` | Closes a multi-line expression or function call that started on previous lines. |
| 198 | `        return text.lower().strip().strip(".").strip() in noise_phrases` | Returns a value to the caller and usually ends the current function. |
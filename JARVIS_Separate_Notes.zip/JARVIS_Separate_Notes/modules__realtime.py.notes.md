# Notes for `modules/realtime.py`

## File purpose
Realtime information module. It handles weather, time/date, location, search, system stats, and online/local utility answers.

## Main classes and functions

- `get_melbourne_time()` starts at line 20: reusable logic block — Always returns current Melbourne time, regardless of system clock timezone.
- `get_datetime_string()` starts at line 26: reusable logic block — Human-readable Melbourne date and time.
- `get_time_response()` starts at line 32: reusable logic block
- `get_weather()` starts at line 39: reusable logic block — Fetches Melbourne weather from wttr.in — completely free, no API key.
Returns a short description like: "Partly cloudy +18°C 65% 15km/h"
- `get_weather_response()` starts at line 54: reusable logic block
- `get_full_weather()` starts at line 67: reusable logic block — Detailed weather for when user asks for full forecast.
- `web_search()` starts at line 80: reusable logic block — Searches DuckDuckGo Instant Answers API — free, no key needed.
Returns a short summary of the top result.
- `get_system_stats()` starts at line 112: reusable logic block — Returns GPU/CPU/RAM stats.
- `get_location()` starts at line 156: reusable logic block — Auto-detects city, country, timezone from IP address.
Free, no API key. Falls back to config values if offline.
Only hits the internet when explicitly called.
- `find_nearby()` starts at line 187: reusable logic block — Opens Google Maps in the browser searching for query near current location.
Only hits the internet when called — never runs in the background.
Falls back gracefully if location detection fails.
- `parse_and_handle()` starts at line 223: reusable logic block

## Why the sequence/order matters

The file follows the usual Python order: documentation, imports, constants/classes/functions, and finally executable entry logic. That sequence makes dependencies available before they are used.

## Line-by-line notes

| Line | Code | Explanation |
|---:|---|---|
| 1 | `"""` | Docstring/comment text: explains the purpose of the file, class, or function for humans and tools. |
| 2 | `modules/realtime.py` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 3 | `Real-time data: weather, time/date (Melbourne), news, web search.` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 4 | `No API keys needed — uses free public sources.` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 5 | `"""` | Docstring/comment text: explains the purpose of the file, class, or function for humans and tools. |
| 6 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 7 | `import re` | Imports a module so this file can use features that are not built into the current namespace. |
| 8 | `import json` | Imports a module so this file can use features that are not built into the current namespace. |
| 9 | `import urllib.request` | Imports a module so this file can use features that are not built into the current namespace. |
| 10 | `import urllib.parse` | Imports a module so this file can use features that are not built into the current namespace. |
| 11 | `import webbrowser` | Imports a module so this file can use features that are not built into the current namespace. |
| 12 | `from datetime import datetime` | Imports selected classes/functions/constants from another module to keep this file focused and avoid repeating code. |
| 13 | `import pytz` | Imports a module so this file can use features that are not built into the current namespace. |
| 14 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 15 | `from config import TIMEZONE, USER_COUNTRY, WEATHER_CITY, USER_CITY` | Imports selected classes/functions/constants from another module to keep this file focused and avoid repeating code. |
| 16 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 17 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 18 | `# ── Time & Date ────────────────────────────────────────────────────────────────` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 19 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 20 | `def get_melbourne_time() -> datetime:` | Defines a function/method so this behaviour can be called later and kept separate from other logic. |
| 21 | `    """Always returns current Melbourne time, regardless of system clock timezone."""` | Docstring/comment text: explains the purpose of the file, class, or function for humans and tools. |
| 22 | `    tz = pytz.timezone(TIMEZONE)` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 23 | `    return datetime.now(tz)` | Returns a value to the caller and usually ends the current function. |
| 24 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 25 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 26 | `def get_datetime_string() -> str:` | Defines a function/method so this behaviour can be called later and kept separate from other logic. |
| 27 | `    """Human-readable Melbourne date and time."""` | Docstring/comment text: explains the purpose of the file, class, or function for humans and tools. |
| 28 | `    now = get_melbourne_time()` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 29 | `    return now.strftime("%A, %d %B %Y — %I:%M %p AEST")` | Returns a value to the caller and usually ends the current function. |
| 30 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 31 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 32 | `def get_time_response() -> str:` | Defines a function/method so this behaviour can be called later and kept separate from other logic. |
| 33 | `    now = get_melbourne_time()` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 34 | `    return f"It's {now.strftime('%I:%M %p')} here in Melbourne — {now.strftime('%A, %d %B %Y')}."` | Returns a value to the caller and usually ends the current function. |
| 35 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 36 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 37 | `# ── Weather ────────────────────────────────────────────────────────────────────` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 38 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 39 | `def get_weather() -> str:` | Defines a function/method so this behaviour can be called later and kept separate from other logic. |
| 40 | `    """` | Docstring/comment text: explains the purpose of the file, class, or function for humans and tools. |
| 41 | `    Fetches Melbourne weather from wttr.in — completely free, no API key.` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 42 | `    Returns a short description like: "Partly cloudy +18°C 65% 15km/h"` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 43 | `    """` | Docstring/comment text: explains the purpose of the file, class, or function for humans and tools. |
| 44 | `    try:` | Starts error-handling block so failures can be caught without crashing the whole assistant. |
| 45 | `        url = f"https://wttr.in/{WEATHER_CITY}?format=%C+%t+Humidity:%h+Wind:%w"` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 46 | `        req = urllib.request.Request(url, headers={"User-Agent": "JARVIS/1.0"})` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 47 | `        with urllib.request.urlopen(req, timeout=5) as resp:` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 48 | `            raw = resp.read().decode("utf-8").strip()` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 49 | `        return raw` | Returns a value to the caller and usually ends the current function. |
| 50 | `    except Exception:` | Handles a specific failure path; this keeps the program stable when something goes wrong. |
| 51 | `        return "Weather unavailable right now"` | Returns a value to the caller and usually ends the current function. |
| 52 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 53 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 54 | `def get_weather_response() -> str:` | Defines a function/method so this behaviour can be called later and kept separate from other logic. |
| 55 | `    weather = get_weather()` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 56 | `    now = get_melbourne_time()` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 57 | `    hour = now.hour` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 58 | `    if hour < 12:` | Conditional check: chooses the next action depending on the current state or user input. |
| 59 | `        time_part = "this morning"` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 60 | `    elif hour < 17:` | Alternative conditional branch checked only if previous `if`/`elif` conditions failed. |
| 61 | `        time_part = "this afternoon"` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 62 | `    else:` | Fallback branch used when no earlier condition matched. |
| 63 | `        time_part = "this evening"` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 64 | `    return f"In Melbourne {time_part}: {weather}."` | Returns a value to the caller and usually ends the current function. |
| 65 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 66 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 67 | `def get_full_weather() -> str:` | Defines a function/method so this behaviour can be called later and kept separate from other logic. |
| 68 | `    """Detailed weather for when user asks for full forecast."""` | Docstring/comment text: explains the purpose of the file, class, or function for humans and tools. |
| 69 | `    try:` | Starts error-handling block so failures can be caught without crashing the whole assistant. |
| 70 | `        url = f"https://wttr.in/{WEATHER_CITY}?format=3"` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 71 | `        req = urllib.request.Request(url, headers={"User-Agent": "JARVIS/1.0"})` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 72 | `        with urllib.request.urlopen(req, timeout=5) as resp:` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 73 | `            return resp.read().decode("utf-8").strip()` | Returns a value to the caller and usually ends the current function. |
| 74 | `    except Exception:` | Handles a specific failure path; this keeps the program stable when something goes wrong. |
| 75 | `        return "Couldn't fetch weather right now."` | Returns a value to the caller and usually ends the current function. |
| 76 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 77 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 78 | `# ── Web Search (DuckDuckGo, no API key) ───────────────────────────────────────` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 79 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 80 | `def web_search(query: str, max_results: int = 3) -> str:` | Defines a function/method so this behaviour can be called later and kept separate from other logic. |
| 81 | `    """` | Docstring/comment text: explains the purpose of the file, class, or function for humans and tools. |
| 82 | `    Searches DuckDuckGo Instant Answers API — free, no key needed.` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 83 | `    Returns a short summary of the top result.` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 84 | `    """` | Docstring/comment text: explains the purpose of the file, class, or function for humans and tools. |
| 85 | `    try:` | Starts error-handling block so failures can be caught without crashing the whole assistant. |
| 86 | `        encoded = urllib.parse.quote(query)` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 87 | `        url = f"https://api.duckduckgo.com/?q={encoded}&format=json&no_html=1&skip_disambig=1"` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 88 | `        req = urllib.request.Request(url, headers={"User-Agent": "JARVIS/1.0"})` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 89 | `        with urllib.request.urlopen(req, timeout=6) as resp:` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 90 | `            data = json.loads(resp.read().decode("utf-8"))` | Reads or writes JSON, which is used here because memory/todo data must persist after the program closes. |
| 91 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 92 | `        # Try abstract (Wikipedia-style answer)` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 93 | `        if data.get("AbstractText"):` | Conditional check: chooses the next action depending on the current state or user input. |
| 94 | `            return data["AbstractText"][:400]` | Returns a value to the caller and usually ends the current function. |
| 95 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 96 | `        # Try answer (direct factual)` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 97 | `        if data.get("Answer"):` | Conditional check: chooses the next action depending on the current state or user input. |
| 98 | `            return data["Answer"]` | Returns a value to the caller and usually ends the current function. |
| 99 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 100 | `        # Try related topics` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 101 | `        topics = data.get("RelatedTopics", [])` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 102 | `        if topics and isinstance(topics[0], dict):` | Conditional check: chooses the next action depending on the current state or user input. |
| 103 | `            return topics[0].get("Text", "")[:300]` | Returns a value to the caller and usually ends the current function. |
| 104 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 105 | `        return f"I searched for '{query}' but couldn't find a clear answer."` | Returns a value to the caller and usually ends the current function. |
| 106 | `    except Exception as e:` | Handles a specific failure path; this keeps the program stable when something goes wrong. |
| 107 | `        return f"Search failed: {e}"` | Returns a value to the caller and usually ends the current function. |
| 108 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 109 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 110 | `# ── System info ───────────────────────────────────────────────────────────────` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 111 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 112 | `def get_system_stats() -> str:` | Defines a function/method so this behaviour can be called later and kept separate from other logic. |
| 113 | `    """Returns GPU/CPU/RAM stats."""` | Docstring/comment text: explains the purpose of the file, class, or function for humans and tools. |
| 114 | `    import subprocess` | Imports a module so this file can use features that are not built into the current namespace. |
| 115 | `    import torch` | Imports a module so this file can use features that are not built into the current namespace. |
| 116 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 117 | `    parts = []` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 118 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 119 | `    # GPU via PyTorch` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 120 | `    if torch.cuda.is_available():` | Conditional check: chooses the next action depending on the current state or user input. |
| 121 | `        used  = torch.cuda.memory_allocated(0)  / 1024**3` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 122 | `        total = torch.cuda.get_device_properties(0).total_memory / 1024**3` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 123 | `        name  = torch.cuda.get_device_name(0)` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 124 | `        parts.append(f"GPU: {name} — {used:.1f}/{total:.0f} GB VRAM used")` | Closes a multi-line expression or function call that started on previous lines. |
| 125 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 126 | `    # nvidia-smi for temp + utilisation` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 127 | `    try:` | Starts error-handling block so failures can be caught without crashing the whole assistant. |
| 128 | `        out = subprocess.run(` | Runs an external operating-system command or program; needed for launching apps or Windows tasks. |
| 129 | `            "nvidia-smi --query-gpu=temperature.gpu,utilization.gpu --format=csv,noheader",` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 130 | `            capture_output=True, text=True, shell=True, timeout=3` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 131 | `        ).stdout.strip()` | Closes a multi-line expression or function call that started on previous lines. |
| 132 | `        if out:` | Conditional check: chooses the next action depending on the current state or user input. |
| 133 | `            temp, util = out.split(", ")` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 134 | `            parts.append(f"GPU temp: {temp}°C, utilisation: {util}")` | Closes a multi-line expression or function call that started on previous lines. |
| 135 | `    except Exception:` | Handles a specific failure path; this keeps the program stable when something goes wrong. |
| 136 | `        pass` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 137 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 138 | `    # RAM` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 139 | `    try:` | Starts error-handling block so failures can be caught without crashing the whole assistant. |
| 140 | `        out = subprocess.run(` | Runs an external operating-system command or program; needed for launching apps or Windows tasks. |
| 141 | `            'wmic OS get FreePhysicalMemory,TotalVisibleMemorySize /value',` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 142 | `            capture_output=True, text=True, shell=True, timeout=3` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 143 | `        ).stdout` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 144 | `        lines = {l.split("=")[0]: l.split("=")[1] for l in out.strip().splitlines() if "=" in l}` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 145 | `        free  = int(lines.get("FreePhysicalMemory", 0))  / 1024**2` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 146 | `        total = int(lines.get("TotalVisibleMemorySize", 0)) / 1024**2` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 147 | `        parts.append(f"RAM: {total - free:.1f}/{total:.0f} GB used")` | Closes a multi-line expression or function call that started on previous lines. |
| 148 | `    except Exception:` | Handles a specific failure path; this keeps the program stable when something goes wrong. |
| 149 | `        pass` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 150 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 151 | `    return "\n".join(parts) if parts else "System stats unavailable."` | Returns a value to the caller and usually ends the current function. |
| 152 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 153 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 154 | `# ── Location (IP-based, only called when needed) ───────────────────────────────` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 155 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 156 | `def get_location() -> dict:` | Defines a function/method so this behaviour can be called later and kept separate from other logic. |
| 157 | `    """` | Docstring/comment text: explains the purpose of the file, class, or function for humans and tools. |
| 158 | `    Auto-detects city, country, timezone from IP address.` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 159 | `    Free, no API key. Falls back to config values if offline.` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 160 | `    Only hits the internet when explicitly called.` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 161 | `    """` | Docstring/comment text: explains the purpose of the file, class, or function for humans and tools. |
| 162 | `    try:` | Starts error-handling block so failures can be caught without crashing the whole assistant. |
| 163 | `        url = "http://ip-api.com/json/?fields=city,country,timezone,lat,lon"` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 164 | `        req = urllib.request.Request(url, headers={"User-Agent": "JARVIS/1.0"})` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 165 | `        with urllib.request.urlopen(req, timeout=5) as resp:` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 166 | `            data = json.loads(resp.read().decode("utf-8"))` | Reads or writes JSON, which is used here because memory/todo data must persist after the program closes. |
| 167 | `        return {` | Returns a value to the caller and usually ends the current function. |
| 168 | `            "city":     data.get("city",     WEATHER_CITY),` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 169 | `            "country":  data.get("country",  USER_COUNTRY),` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 170 | `            "timezone": data.get("timezone", TIMEZONE),` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 171 | `            "lat":      data.get("lat",      0),` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 172 | `            "lon":      data.get("lon",      0),` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 173 | `        }` | Closes a multi-line expression or function call that started on previous lines. |
| 174 | `    except Exception:` | Handles a specific failure path; this keeps the program stable when something goes wrong. |
| 175 | `        # Offline fallback — use config values` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 176 | `        return {` | Returns a value to the caller and usually ends the current function. |
| 177 | `            "city":     WEATHER_CITY,` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 178 | `            "country":  USER_COUNTRY,` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 179 | `            "timezone": TIMEZONE,` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 180 | `            "lat":      0,` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 181 | `            "lon":      0,` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 182 | `        }` | Closes a multi-line expression or function call that started on previous lines. |
| 183 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 184 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 185 | `# ── Nearby Places Search ───────────────────────────────────────────────────────` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 186 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 187 | `def find_nearby(query: str) -> str:` | Defines a function/method so this behaviour can be called later and kept separate from other logic. |
| 188 | `    """` | Docstring/comment text: explains the purpose of the file, class, or function for humans and tools. |
| 189 | `    Opens Google Maps in the browser searching for query near current location.` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 190 | `    Only hits the internet when called — never runs in the background.` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 191 | `    Falls back gracefully if location detection fails.` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 192 | `    """` | Docstring/comment text: explains the purpose of the file, class, or function for humans and tools. |
| 193 | `    try:` | Starts error-handling block so failures can be caught without crashing the whole assistant. |
| 194 | `        loc  = get_location()` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 195 | `        city = loc["city"]` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 196 | `        lat  = loc["lat"]` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 197 | `        lon  = loc["lon"]` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 198 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 199 | `        # If we got real coordinates, use them for more accurate results` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 200 | `        if lat and lon:` | Conditional check: chooses the next action depending on the current state or user input. |
| 201 | `            encoded = urllib.parse.quote(query)` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 202 | `            url = (` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 203 | `                f"https://www.google.com/maps/search/{encoded}"` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 204 | `                f"/@{lat},{lon},14z"` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 205 | `            )` | Closes a multi-line expression or function call that started on previous lines. |
| 206 | `        else:` | Fallback branch used when no earlier condition matched. |
| 207 | `            # Fall back to city name search` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 208 | `            encoded = urllib.parse.quote(f"{query} near {city}")` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 209 | `            url = f"https://www.google.com/maps/search/{encoded}"` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 210 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 211 | `        webbrowser.open(url)` | Closes a multi-line expression or function call that started on previous lines. |
| 212 | `        return f"Opening Google Maps for {query} near {city}."` | Returns a value to the caller and usually ends the current function. |
| 213 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 214 | `    except Exception:` | Handles a specific failure path; this keeps the program stable when something goes wrong. |
| 215 | `        # Last resort — open Maps with just the query` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 216 | `        encoded = urllib.parse.quote(query)` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 217 | `        webbrowser.open(f"https://www.google.com/maps/search/{encoded}")` | Closes a multi-line expression or function call that started on previous lines. |
| 218 | `        return f"Opening Google Maps for {query}."` | Returns a value to the caller and usually ends the current function. |
| 219 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 220 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 221 | `# ── Intent router ─────────────────────────────────────────────────────────────` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 222 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 223 | `def parse_and_handle(text: str) -> str \| None:` | Defines a function/method so this behaviour can be called later and kept separate from other logic. |
| 224 | `    text_lower = text.lower().strip()` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 225 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 226 | `    # Time / date` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 227 | `    if re.search(r"\b(time\|date\|day\|today\|what day\|what time)\b", text_lower):` | Conditional check: chooses the next action depending on the current state or user input. |
| 228 | `        if re.search(r"\b(weather\|temperature\|temp\|forecast)\b", text_lower):` | Conditional check: chooses the next action depending on the current state or user input. |
| 229 | `            pass  # fall through to weather` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 230 | `        else:` | Fallback branch used when no earlier condition matched. |
| 231 | `            return get_time_response()` | Returns a value to the caller and usually ends the current function. |
| 232 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 233 | `    # Weather` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 234 | `    if re.search(r"\b(weather\|temperature\|temp\|forecast\|raining\|hot\|cold\|sunny)\b", text_lower):` | Conditional check: chooses the next action depending on the current state or user input. |
| 235 | `        if "forecast" in text_lower or "week" in text_lower:` | Conditional check: chooses the next action depending on the current state or user input. |
| 236 | `            return get_full_weather()` | Returns a value to the caller and usually ends the current function. |
| 237 | `        return get_weather_response()` | Returns a value to the caller and usually ends the current function. |
| 238 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 239 | `    # System stats` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 240 | `    if re.search(r"\b(gpu\|cpu\|ram\|memory\|vram\|stats\|system info\|performance)\b", text_lower):` | Conditional check: chooses the next action depending on the current state or user input. |
| 241 | `        return get_system_stats()` | Returns a value to the caller and usually ends the current function. |
| 242 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 243 | `    # Nearby places — must come BEFORE generic web search` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 244 | `    # catches: "find a coffee bar near me", "any restaurants nearby",` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 245 | `    #          "where's a pharmacy close by", "look for a gym around here"` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 246 | `    m = re.search(` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 247 | `        r"(?:find\|search for\|look for\|where(?:'s\| is)\|any\|get me)\s+(.+?)\s+"` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 248 | `        r"(?:near me\|nearby\|close by\|around here\|near here)",` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 249 | `        text_lower` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 250 | `    )` | Closes a multi-line expression or function call that started on previous lines. |
| 251 | `    if m:` | Conditional check: chooses the next action depending on the current state or user input. |
| 252 | `        return find_nearby(m.group(1).strip())` | Returns a value to the caller and usually ends the current function. |
| 253 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 254 | `    # Web search` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 255 | `    m = re.search(r"(?:search\|look up\|google\|find\|what is\|who is\|tell me about)\s+(.+)", text_lower)` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 256 | `    if m:` | Conditional check: chooses the next action depending on the current state or user input. |
| 257 | `        query = m.group(1).strip()` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 258 | `        result = web_search(query)` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 259 | `        return result if result else None` | Returns a value to the caller and usually ends the current function. |
| 260 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 261 | `    return None` | Returns a value to the caller and usually ends the current function. |
# Notes for `gui.py`

## File purpose
PyQt6 dashboard. It runs JARVIS in a background thread and updates the interface using Qt signals so the UI does not freeze.

## Main classes and functions

- `class Signals` starts at line 22: groups related state and behaviours. It is used because JARVIS needs reusable objects rather than loose code everywhere.
- `class JARVISThread` starts at line 32: groups related state and behaviours. It is used because JARVIS needs reusable objects rather than loose code everywhere.
- `class JARVISDashboard` starts at line 96: groups related state and behaviours. It is used because JARVIS needs reusable objects rather than loose code everywhere.
- `__init__()` starts at line 33: reusable logic block
- `run()` starts at line 37: reusable logic block
- `__init__()` starts at line 98: reusable logic block
- `_build()` starts at line 124: reusable logic block
- `_connect()` starts at line 226: reusable logic block
- `_on_status()` starts at line 231: reusable logic block
- `_set_state()` starts at line 248: reusable logic block
- `_append_msg()` starts at line 255: reusable logic block
- `_update_todos()` starts at line 275: reusable logic block
- `_animate()` starts at line 283: reusable logic block
- `_update_clock()` starts at line 286: reusable logic block
- `hook()` starts at line 38: reusable logic block

## Why the sequence/order matters

Qt signals are defined before the background thread and dashboard because both need to use them. The background thread exists so listening/speaking does not freeze the GUI.

## Line-by-line notes

| Line | Code | Explanation |
|---:|---|---|
| 1 | `"""` | Docstring/comment text: explains the purpose of the file, class, or function for humans and tools. |
| 2 | `gui.py — PyQt6 dashboard for JARVIS v2.` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 3 | `Shows status, conversation log, todo list, and memory stats.` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 4 | `"""` | Docstring/comment text: explains the purpose of the file, class, or function for humans and tools. |
| 5 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 6 | `import sys` | Imports a module so this file can use features that are not built into the current namespace. |
| 7 | `import threading` | Imports a module so this file can use features that are not built into the current namespace. |
| 8 | `from datetime import datetime` | Imports selected classes/functions/constants from another module to keep this file focused and avoid repeating code. |
| 9 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 10 | `from PyQt6.QtWidgets import (` | Imports selected classes/functions/constants from another module to keep this file focused and avoid repeating code. |
| 11 | `    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 12 | `    QLabel, QTextEdit, QPushButton, QFrame, QListWidget,` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 13 | `    QListWidgetItem, QSplitter, QLineEdit` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 14 | `)` | Closes a multi-line expression or function call that started on previous lines. |
| 15 | `from PyQt6.QtCore import Qt, QTimer, pyqtSignal, QObject, QThread` | Imports selected classes/functions/constants from another module to keep this file focused and avoid repeating code. |
| 16 | `from PyQt6.QtGui import QTextCursor, QFont` | Imports selected classes/functions/constants from another module to keep this file focused and avoid repeating code. |
| 17 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 18 | `from jarvis import JARVIS` | Imports selected classes/functions/constants from another module to keep this file focused and avoid repeating code. |
| 19 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 20 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 21 | `# ── Signals (thread-safe UI updates) ──────────────────────────────────────────` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 22 | `class Signals(QObject):` | Defines a class, grouping related data and methods into one reusable object. |
| 23 | `    status  = pyqtSignal(str, str)   # (state, text)` | Qt signal logic: safely sends updates from background code to the GUI thread. |
| 24 | `    log_msg = pyqtSignal(str, str)   # (role, text)` | Qt signal logic: safely sends updates from background code to the GUI thread. |
| 25 | `    todos   = pyqtSignal(list)       # updated todo list` | Qt signal logic: safely sends updates from background code to the GUI thread. |
| 26 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 27 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 28 | `signals = Signals()` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 29 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 30 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 31 | `# ── JARVIS background thread ───────────────────────────────────────────────────` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 32 | `class JARVISThread(QThread):` | Defines a class, grouping related data and methods into one reusable object. |
| 33 | `    def __init__(self):` | Defines a function/method so this behaviour can be called later and kept separate from other logic. |
| 34 | `        super().__init__()` | Closes a multi-line expression or function call that started on previous lines. |
| 35 | `        self.jarvis = None` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 36 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 37 | `    def run(self):` | Defines a function/method so this behaviour can be called later and kept separate from other logic. |
| 38 | `        def hook(state, text):` | Defines a function/method so this behaviour can be called later and kept separate from other logic. |
| 39 | `            signals.status.emit(state, text)` | Qt signal logic: safely sends updates from background code to the GUI thread. |
| 40 | `            if state == "thinking" and text:` | Conditional check: chooses the next action depending on the current state or user input. |
| 41 | `                signals.log_msg.emit("YOU", text)` | Qt signal logic: safely sends updates from background code to the GUI thread. |
| 42 | `            elif state == "speaking" and text:` | Alternative conditional branch checked only if previous `if`/`elif` conditions failed. |
| 43 | `                signals.log_msg.emit("JARVIS", text)` | Qt signal logic: safely sends updates from background code to the GUI thread. |
| 44 | `                # Update todos after potential todo changes` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 45 | `                if self.jarvis:` | Conditional check: chooses the next action depending on the current state or user input. |
| 46 | `                    pending = [t for t in self.jarvis.todos.todos if not t["done"]]` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 47 | `                    signals.todos.emit(pending)` | Qt signal logic: safely sends updates from background code to the GUI thread. |
| 48 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 49 | `        self.jarvis = JARVIS(status_callback=hook)` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 50 | `        self.jarvis.start()` | Closes a multi-line expression or function call that started on previous lines. |
| 51 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 52 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 53 | `# ── Stylesheet ────────────────────────────────────────────────────────────────` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 54 | `STYLE = """` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 55 | `QMainWindow, QWidget { background:#080c10; color:#c8dce8; }` | Closes a multi-line expression or function call that started on previous lines. |
| 56 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 57 | `QLabel#title {` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 58 | `    font-size:28px; font-weight:800; letter-spacing:10px;` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 59 | `    color:#4fc3f7; font-family:'Courier New';` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 60 | `}` | Closes a multi-line expression or function call that started on previous lines. |
| 61 | `QLabel#sub { font-size:9px; letter-spacing:3px; color:#1d3a50; font-family:'Courier New'; }` | Closes a multi-line expression or function call that started on previous lines. |
| 62 | `QLabel#status { font-size:10px; letter-spacing:2px; color:#4fc3f7; font-family:'Courier New'; }` | Closes a multi-line expression or function call that started on previous lines. |
| 63 | `QLabel#ind { font-size:9px; letter-spacing:1px; color:#1a3a50; font-family:'Courier New'; }` | Closes a multi-line expression or function call that started on previous lines. |
| 64 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 65 | `QTextEdit#log {` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 66 | `    background:#050810; color:#8fb8c8; border:0.5px solid #0d2030;` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 67 | `    border-radius:4px; font-family:'Courier New'; font-size:11px; padding:8px;` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 68 | `}` | Closes a multi-line expression or function call that started on previous lines. |
| 69 | `QListWidget#todos {` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 70 | `    background:#050810; color:#c8dce8; border:0.5px solid #0d2030;` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 71 | `    border-radius:4px; font-family:'Courier New'; font-size:11px; padding:4px;` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 72 | `}` | Closes a multi-line expression or function call that started on previous lines. |
| 73 | `QListWidget#todos::item { padding:4px 6px; border-bottom:0.5px solid #0d2030; }` | Closes a multi-line expression or function call that started on previous lines. |
| 74 | `QListWidget#todos::item:selected { background:#1a3a50; }` | Closes a multi-line expression or function call that started on previous lines. |
| 75 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 76 | `QPushButton {` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 77 | `    background:#0d1f2d; color:#4fc3f7; border:0.5px solid #1a3a50;` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 78 | `    border-radius:3px; padding:5px 12px; font-family:'Courier New';` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 79 | `    font-size:9px; letter-spacing:2px;` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 80 | `}` | Closes a multi-line expression or function call that started on previous lines. |
| 81 | `QPushButton:hover { background:#1a3a50; border-color:#4fc3f7; }` | Closes a multi-line expression or function call that started on previous lines. |
| 82 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 83 | `QFrame#sep { color:#0d2030; max-height:1px; }` | Closes a multi-line expression or function call that started on previous lines. |
| 84 | `QLabel#section { font-size:9px; color:#2a5a7a; letter-spacing:3px; font-family:'Courier New'; }` | Closes a multi-line expression or function call that started on previous lines. |
| 85 | `"""` | Docstring/comment text: explains the purpose of the file, class, or function for humans and tools. |
| 86 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 87 | `STATE_COLORS = {` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 88 | `    "offline":   ("#555",    "● OFFLINE"),` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 89 | `    "loading":   ("#f59e0b", "● INITIALISING"),` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 90 | `    "listening": ("#22c55e", "● LISTENING"),` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 91 | `    "thinking":  ("#f59e0b", "● PROCESSING"),` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 92 | `    "speaking":  ("#4fc3f7", "● SPEAKING"),` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 93 | `}` | Closes a multi-line expression or function call that started on previous lines. |
| 94 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 95 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 96 | `class JARVISDashboard(QMainWindow):` | Defines a class, grouping related data and methods into one reusable object. |
| 97 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 98 | `    def __init__(self):` | Defines a function/method so this behaviour can be called later and kept separate from other logic. |
| 99 | `        super().__init__()` | Closes a multi-line expression or function call that started on previous lines. |
| 100 | `        self.setWindowTitle("JARVIS")` | Closes a multi-line expression or function call that started on previous lines. |
| 101 | `        self.resize(1000, 680)` | Closes a multi-line expression or function call that started on previous lines. |
| 102 | `        self.setMinimumSize(800, 500)` | Closes a multi-line expression or function call that started on previous lines. |
| 103 | `        self.setStyleSheet(STYLE)` | Closes a multi-line expression or function call that started on previous lines. |
| 104 | `        self._build()` | Closes a multi-line expression or function call that started on previous lines. |
| 105 | `        self._connect()` | Closes a multi-line expression or function call that started on previous lines. |
| 106 | `        self._set_state("loading")` | Closes a multi-line expression or function call that started on previous lines. |
| 107 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 108 | `        # Animated status` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 109 | `        self._tick = 0` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 110 | `        self._anim = QTimer()` | Creates or configures a PyQt GUI widget/layout so the dashboard can show controls and information. |
| 111 | `        self._anim.timeout.connect(self._animate)` | Closes a multi-line expression or function call that started on previous lines. |
| 112 | `        self._anim.start(500)` | Closes a multi-line expression or function call that started on previous lines. |
| 113 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 114 | `        # Clock` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 115 | `        self._clock = QTimer()` | Creates or configures a PyQt GUI widget/layout so the dashboard can show controls and information. |
| 116 | `        self._clock.timeout.connect(self._update_clock)` | Closes a multi-line expression or function call that started on previous lines. |
| 117 | `        self._clock.start(1000)` | Closes a multi-line expression or function call that started on previous lines. |
| 118 | `        self._update_clock()` | Closes a multi-line expression or function call that started on previous lines. |
| 119 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 120 | `        # Start JARVIS` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 121 | `        self.thread = JARVISThread()` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 122 | `        self.thread.start()` | Closes a multi-line expression or function call that started on previous lines. |
| 123 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 124 | `    def _build(self):` | Defines a function/method so this behaviour can be called later and kept separate from other logic. |
| 125 | `        root_w = QWidget()` | Creates or configures a PyQt GUI widget/layout so the dashboard can show controls and information. |
| 126 | `        self.setCentralWidget(root_w)` | Closes a multi-line expression or function call that started on previous lines. |
| 127 | `        root = QHBoxLayout(root_w)` | Creates or configures a PyQt GUI widget/layout so the dashboard can show controls and information. |
| 128 | `        root.setContentsMargins(0, 0, 0, 0)` | Closes a multi-line expression or function call that started on previous lines. |
| 129 | `        root.setSpacing(0)` | Closes a multi-line expression or function call that started on previous lines. |
| 130 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 131 | `        # ── Left panel ─────────────────────────────────────────────────────────` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 132 | `        left = QWidget()` | Creates or configures a PyQt GUI widget/layout so the dashboard can show controls and information. |
| 133 | `        left.setFixedWidth(220)` | Closes a multi-line expression or function call that started on previous lines. |
| 134 | `        left.setStyleSheet("background:#060b0f; border-right:0.5px solid #0d2030;")` | Closes a multi-line expression or function call that started on previous lines. |
| 135 | `        lv = QVBoxLayout(left)` | Creates or configures a PyQt GUI widget/layout so the dashboard can show controls and information. |
| 136 | `        lv.setContentsMargins(16, 20, 16, 16)` | Closes a multi-line expression or function call that started on previous lines. |
| 137 | `        lv.setSpacing(0)` | Closes a multi-line expression or function call that started on previous lines. |
| 138 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 139 | `        title = QLabel("J.A.R.V.I.S")` | Creates or configures a PyQt GUI widget/layout so the dashboard can show controls and information. |
| 140 | `        title.setObjectName("title")` | Closes a multi-line expression or function call that started on previous lines. |
| 141 | `        title.setStyleSheet("font-size:20px; letter-spacing:6px;")` | Closes a multi-line expression or function call that started on previous lines. |
| 142 | `        lv.addWidget(title)` | Closes a multi-line expression or function call that started on previous lines. |
| 143 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 144 | `        sub = QLabel("PERSONAL AI")` | Creates or configures a PyQt GUI widget/layout so the dashboard can show controls and information. |
| 145 | `        sub.setObjectName("sub")` | Closes a multi-line expression or function call that started on previous lines. |
| 146 | `        lv.addWidget(sub)` | Closes a multi-line expression or function call that started on previous lines. |
| 147 | `        lv.addSpacing(20)` | Closes a multi-line expression or function call that started on previous lines. |
| 148 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 149 | `        self.status_lbl = QLabel("● OFFLINE")` | Creates or configures a PyQt GUI widget/layout so the dashboard can show controls and information. |
| 150 | `        self.status_lbl.setObjectName("status")` | Closes a multi-line expression or function call that started on previous lines. |
| 151 | `        lv.addWidget(self.status_lbl)` | Closes a multi-line expression or function call that started on previous lines. |
| 152 | `        lv.addSpacing(6)` | Closes a multi-line expression or function call that started on previous lines. |
| 153 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 154 | `        self.clock_lbl = QLabel()` | Creates or configures a PyQt GUI widget/layout so the dashboard can show controls and information. |
| 155 | `        self.clock_lbl.setObjectName("ind")` | Closes a multi-line expression or function call that started on previous lines. |
| 156 | `        lv.addWidget(self.clock_lbl)` | Closes a multi-line expression or function call that started on previous lines. |
| 157 | `        lv.addSpacing(24)` | Closes a multi-line expression or function call that started on previous lines. |
| 158 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 159 | `        sep = QFrame(); sep.setObjectName("sep"); sep.setFrameShape(QFrame.Shape.HLine)` | Creates or configures a PyQt GUI widget/layout so the dashboard can show controls and information. |
| 160 | `        lv.addWidget(sep)` | Closes a multi-line expression or function call that started on previous lines. |
| 161 | `        lv.addSpacing(16)` | Closes a multi-line expression or function call that started on previous lines. |
| 162 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 163 | `        # Todos panel` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 164 | `        todo_lbl = QLabel("TODO LIST")` | Creates or configures a PyQt GUI widget/layout so the dashboard can show controls and information. |
| 165 | `        todo_lbl.setObjectName("section")` | Closes a multi-line expression or function call that started on previous lines. |
| 166 | `        lv.addWidget(todo_lbl)` | Closes a multi-line expression or function call that started on previous lines. |
| 167 | `        lv.addSpacing(6)` | Closes a multi-line expression or function call that started on previous lines. |
| 168 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 169 | `        self.todo_list = QListWidget()` | Creates or configures a PyQt GUI widget/layout so the dashboard can show controls and information. |
| 170 | `        self.todo_list.setObjectName("todos")` | Closes a multi-line expression or function call that started on previous lines. |
| 171 | `        lv.addWidget(self.todo_list, 1)` | Closes a multi-line expression or function call that started on previous lines. |
| 172 | `        lv.addSpacing(8)` | Closes a multi-line expression or function call that started on previous lines. |
| 173 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 174 | `        self.todo_count = QLabel("0 pending")` | Creates or configures a PyQt GUI widget/layout so the dashboard can show controls and information. |
| 175 | `        self.todo_count.setObjectName("ind")` | Closes a multi-line expression or function call that started on previous lines. |
| 176 | `        lv.addWidget(self.todo_count)` | Closes a multi-line expression or function call that started on previous lines. |
| 177 | `        lv.addSpacing(16)` | Closes a multi-line expression or function call that started on previous lines. |
| 178 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 179 | `        sep2 = QFrame(); sep2.setObjectName("sep"); sep2.setFrameShape(QFrame.Shape.HLine)` | Creates or configures a PyQt GUI widget/layout so the dashboard can show controls and information. |
| 180 | `        lv.addWidget(sep2)` | Closes a multi-line expression or function call that started on previous lines. |
| 181 | `        lv.addSpacing(12)` | Closes a multi-line expression or function call that started on previous lines. |
| 182 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 183 | `        self.mem_lbl = QLabel("MEMORY: 0 turns")` | Creates or configures a PyQt GUI widget/layout so the dashboard can show controls and information. |
| 184 | `        self.mem_lbl.setObjectName("ind")` | Closes a multi-line expression or function call that started on previous lines. |
| 185 | `        lv.addWidget(self.mem_lbl)` | Closes a multi-line expression or function call that started on previous lines. |
| 186 | `        lv.addSpacing(8)` | Closes a multi-line expression or function call that started on previous lines. |
| 187 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 188 | `        clear_btn = QPushButton("CLEAR LOG")` | Creates or configures a PyQt GUI widget/layout so the dashboard can show controls and information. |
| 189 | `        clear_btn.clicked.connect(lambda: self.log.clear())` | Closes a multi-line expression or function call that started on previous lines. |
| 190 | `        lv.addWidget(clear_btn)` | Closes a multi-line expression or function call that started on previous lines. |
| 191 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 192 | `        root.addWidget(left)` | Closes a multi-line expression or function call that started on previous lines. |
| 193 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 194 | `        # ── Main panel ─────────────────────────────────────────────────────────` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 195 | `        main_w = QWidget()` | Creates or configures a PyQt GUI widget/layout so the dashboard can show controls and information. |
| 196 | `        mv = QVBoxLayout(main_w)` | Creates or configures a PyQt GUI widget/layout so the dashboard can show controls and information. |
| 197 | `        mv.setContentsMargins(20, 20, 20, 16)` | Closes a multi-line expression or function call that started on previous lines. |
| 198 | `        mv.setSpacing(10)` | Closes a multi-line expression or function call that started on previous lines. |
| 199 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 200 | `        conv_lbl = QLabel("CONVERSATION")` | Creates or configures a PyQt GUI widget/layout so the dashboard can show controls and information. |
| 201 | `        conv_lbl.setObjectName("section")` | Closes a multi-line expression or function call that started on previous lines. |
| 202 | `        mv.addWidget(conv_lbl)` | Closes a multi-line expression or function call that started on previous lines. |
| 203 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 204 | `        self.log = QTextEdit()` | Creates or configures a PyQt GUI widget/layout so the dashboard can show controls and information. |
| 205 | `        self.log.setObjectName("log")` | Closes a multi-line expression or function call that started on previous lines. |
| 206 | `        self.log.setReadOnly(True)` | Closes a multi-line expression or function call that started on previous lines. |
| 207 | `        mv.addWidget(self.log, 1)` | Closes a multi-line expression or function call that started on previous lines. |
| 208 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 209 | `        # Bottom indicators` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 210 | `        ind_row = QHBoxLayout()` | Creates or configures a PyQt GUI widget/layout so the dashboard can show controls and information. |
| 211 | `        self.indicators = {}` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 212 | `        for name in ["MIC", "STT", "LLM", "TTS", "GPU"]:` | Loop: repeats the following block for every item in a collection or range. |
| 213 | `            lbl = QLabel(f"[ {name} ]")` | Creates or configures a PyQt GUI widget/layout so the dashboard can show controls and information. |
| 214 | `            lbl.setObjectName("ind")` | Closes a multi-line expression or function call that started on previous lines. |
| 215 | `            ind_row.addWidget(lbl)` | Closes a multi-line expression or function call that started on previous lines. |
| 216 | `            self.indicators[name] = lbl` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 217 | `        ind_row.addStretch()` | Closes a multi-line expression or function call that started on previous lines. |
| 218 | `        self.msg_count_lbl = QLabel("MSGS: 000")` | Creates or configures a PyQt GUI widget/layout so the dashboard can show controls and information. |
| 219 | `        self.msg_count_lbl.setObjectName("ind")` | Closes a multi-line expression or function call that started on previous lines. |
| 220 | `        ind_row.addWidget(self.msg_count_lbl)` | Closes a multi-line expression or function call that started on previous lines. |
| 221 | `        mv.addLayout(ind_row)` | Closes a multi-line expression or function call that started on previous lines. |
| 222 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 223 | `        root.addWidget(main_w, 1)` | Closes a multi-line expression or function call that started on previous lines. |
| 224 | `        self._msg_count = 0` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 225 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 226 | `    def _connect(self):` | Defines a function/method so this behaviour can be called later and kept separate from other logic. |
| 227 | `        signals.status.connect(self._on_status)` | Closes a multi-line expression or function call that started on previous lines. |
| 228 | `        signals.log_msg.connect(self._append_msg)` | Closes a multi-line expression or function call that started on previous lines. |
| 229 | `        signals.todos.connect(self._update_todos)` | Closes a multi-line expression or function call that started on previous lines. |
| 230 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 231 | `    def _on_status(self, state, text):` | Defines a function/method so this behaviour can be called later and kept separate from other logic. |
| 232 | `        self._set_state(state)` | Closes a multi-line expression or function call that started on previous lines. |
| 233 | `        active = {` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 234 | `            "listening": ["MIC"],` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 235 | `            "thinking":  ["MIC", "STT", "LLM", "GPU"],` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 236 | `            "speaking":  ["TTS", "GPU"],` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 237 | `            "loading":   ["GPU"],` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 238 | `        }.get(state, [])` | Closes a multi-line expression or function call that started on previous lines. |
| 239 | `        for k, lbl in self.indicators.items():` | Loop: repeats the following block for every item in a collection or range. |
| 240 | `            color = "#4fc3f7" if k in active else "#1a3a50"` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 241 | `            lbl.setStyleSheet(f"color:{color}; font-size:9px; letter-spacing:1px; font-family:'Courier New';")` | Closes a multi-line expression or function call that started on previous lines. |
| 242 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 243 | `        # Update memory count if we have access` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 244 | `        if self.thread.jarvis:` | Conditional check: chooses the next action depending on the current state or user input. |
| 245 | `            n = len(self.thread.jarvis.memory.turns)` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 246 | `            self.mem_lbl.setText(f"MEMORY: {n} turns")` | Closes a multi-line expression or function call that started on previous lines. |
| 247 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 248 | `    def _set_state(self, state):` | Defines a function/method so this behaviour can be called later and kept separate from other logic. |
| 249 | `        color, label = STATE_COLORS.get(state, ("#555", "● OFFLINE"))` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 250 | `        self.status_lbl.setText(label)` | Closes a multi-line expression or function call that started on previous lines. |
| 251 | `        self.status_lbl.setStyleSheet(` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 252 | `            f"color:{color}; font-size:10px; letter-spacing:2px; font-family:'Courier New';"` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 253 | `        )` | Closes a multi-line expression or function call that started on previous lines. |
| 254 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 255 | `    def _append_msg(self, role, text):` | Defines a function/method so this behaviour can be called later and kept separate from other logic. |
| 256 | `        self._msg_count += 1` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 257 | `        self.msg_count_lbl.setText(f"MSGS: {self._msg_count:03d}")` | Closes a multi-line expression or function call that started on previous lines. |
| 258 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 259 | `        ts = datetime.now().strftime("%H:%M")` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 260 | `        if role == "YOU":` | Conditional check: chooses the next action depending on the current state or user input. |
| 261 | `            pc, tc = "#4fc3f7", "#c8dce8"` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 262 | `        else:` | Fallback branch used when no earlier condition matched. |
| 263 | `            pc, tc = "#22c55e", "#8fb8c8"` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 264 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 265 | `        self.log.textCursor().movePosition(QTextCursor.MoveOperation.End)` | Creates or configures a PyQt GUI widget/layout so the dashboard can show controls and information. |
| 266 | `        html = (` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 267 | `            f'<div style="margin:5px 0;font-family:Courier New;font-size:11px;">'` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 268 | `            f'<span style="color:#1a3a50">[{ts}] </span>'` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 269 | `            f'<span style="color:{pc};font-weight:bold">{role} › </span>'` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 270 | `            f'<span style="color:{tc}">{text}</span></div>'` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 271 | `        )` | Closes a multi-line expression or function call that started on previous lines. |
| 272 | `        self.log.textCursor().insertHtml(html)` | Closes a multi-line expression or function call that started on previous lines. |
| 273 | `        self.log.ensureCursorVisible()` | Closes a multi-line expression or function call that started on previous lines. |
| 274 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 275 | `    def _update_todos(self, todos):` | Defines a function/method so this behaviour can be called later and kept separate from other logic. |
| 276 | `        self.todo_list.clear()` | Closes a multi-line expression or function call that started on previous lines. |
| 277 | `        for t in todos:` | Loop: repeats the following block for every item in a collection or range. |
| 278 | `            pri = " ★" if t.get("priority") == "high" else ""` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 279 | `            item = QListWidgetItem(f"○ {t['task']}{pri}")` | Creates or configures a PyQt GUI widget/layout so the dashboard can show controls and information. |
| 280 | `            self.todo_list.addItem(item)` | Closes a multi-line expression or function call that started on previous lines. |
| 281 | `        self.todo_count.setText(f"{len(todos)} pending")` | Closes a multi-line expression or function call that started on previous lines. |
| 282 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 283 | `    def _animate(self):` | Defines a function/method so this behaviour can be called later and kept separate from other logic. |
| 284 | `        self._tick += 1` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 285 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 286 | `    def _update_clock(self):` | Defines a function/method so this behaviour can be called later and kept separate from other logic. |
| 287 | `        from modules.realtime import get_melbourne_time` | Imports selected classes/functions/constants from another module to keep this file focused and avoid repeating code. |
| 288 | `        try:` | Starts error-handling block so failures can be caught without crashing the whole assistant. |
| 289 | `            now = get_melbourne_time()` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 290 | `            self.clock_lbl.setText(now.strftime("%H:%M:%S  AEST"))` | Closes a multi-line expression or function call that started on previous lines. |
| 291 | `        except Exception:` | Handles a specific failure path; this keeps the program stable when something goes wrong. |
| 292 | `            self.clock_lbl.setText(datetime.now().strftime("%H:%M:%S"))` | Closes a multi-line expression or function call that started on previous lines. |
# Notes for `modules/memory.py`

## File purpose
Persistent conversation memory module. It stores and retrieves user/assistant messages from JSON.

## Main classes and functions

- `class Memory` starts at line 16: groups related state and behaviours. It is used because JARVIS needs reusable objects rather than loose code everywhere.
- `__init__()` starts at line 25: reusable logic block
- `load()` starts at line 34: reusable logic block
- `save()` starts at line 44: reusable logic block
- `add()` starts at line 53: reusable logic block — Add a message. Role is 'user' or 'assistant'.
- `add_fact()` starts at line 64: reusable logic block — Store an important fact the user explicitly said to remember.
- `get_context_messages()` starts at line 73: reusable logic block — Returns last MEMORY_CONTEXT turns formatted for Ollama.
Strips timestamps (LLM doesn't need them).
- `get_facts_string()` starts at line 81: reusable logic block — Returns stored facts as a string to inject into the system prompt.
- `stats()` starts at line 90: reusable logic block
- `search()` starts at line 102: reusable logic block — Simple keyword search through memory.
- `parse_and_handle()` starts at line 113: reusable logic block

## Why the sequence/order matters

The file follows the usual Python order: documentation, imports, constants/classes/functions, and finally executable entry logic. That sequence makes dependencies available before they are used.

## Line-by-line notes

| Line | Code | Explanation |
|---:|---|---|
| 1 | `"""` | Docstring/comment text: explains the purpose of the file, class, or function for humans and tools. |
| 2 | `modules/memory.py` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 3 | `Persistent memory — stores EVERY conversation forever in JSON.` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 4 | `Sends the most recent MEMORY_CONTEXT turns to the LLM each time.` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 5 | `"""` | Docstring/comment text: explains the purpose of the file, class, or function for humans and tools. |
| 6 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 7 | `import json` | Imports a module so this file can use features that are not built into the current namespace. |
| 8 | `import re` | Imports a module so this file can use features that are not built into the current namespace. |
| 9 | `from pathlib import Path` | Imports selected classes/functions/constants from another module to keep this file focused and avoid repeating code. |
| 10 | `from datetime import datetime` | Imports selected classes/functions/constants from another module to keep this file focused and avoid repeating code. |
| 11 | `import pytz` | Imports a module so this file can use features that are not built into the current namespace. |
| 12 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 13 | `from config import MEMORY_FILE, MEMORY_CONTEXT, TIMEZONE` | Imports selected classes/functions/constants from another module to keep this file focused and avoid repeating code. |
| 14 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 15 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 16 | `class Memory:` | Defines a class, grouping related data and methods into one reusable object. |
| 17 | `    """` | Docstring/comment text: explains the purpose of the file, class, or function for humans and tools. |
| 18 | `    Full persistent memory system.` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 19 | `    - Saves every single message to disk (never deletes)` | Closes a multi-line expression or function call that started on previous lines. |
| 20 | `    - Loads last MEMORY_CONTEXT turns into LLM context` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 21 | `    - Supports tagging important facts ("remember that...")` | Closes a multi-line expression or function call that started on previous lines. |
| 22 | `    - Searchable history` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 23 | `    """` | Docstring/comment text: explains the purpose of the file, class, or function for humans and tools. |
| 24 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 25 | `    def __init__(self):` | Defines a function/method so this behaviour can be called later and kept separate from other logic. |
| 26 | `        self.path = Path(MEMORY_FILE)` | Uses filesystem path/file handling so the code can safely read, write, or check files. |
| 27 | `        self.path.parent.mkdir(parents=True, exist_ok=True)` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 28 | `        self.turns: list[dict] = []` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 29 | `        self.facts: list[dict] = []   # important facts user explicitly asked to remember` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 30 | `        self.load()` | Closes a multi-line expression or function call that started on previous lines. |
| 31 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 32 | `    # ── Load / Save ────────────────────────────────────────────────────────────` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 33 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 34 | `    def load(self):` | Defines a function/method so this behaviour can be called later and kept separate from other logic. |
| 35 | `        if self.path.exists():` | Conditional check: chooses the next action depending on the current state or user input. |
| 36 | `            try:` | Starts error-handling block so failures can be caught without crashing the whole assistant. |
| 37 | `                data = json.loads(self.path.read_text(encoding="utf-8"))` | Uses filesystem path/file handling so the code can safely read, write, or check files. |
| 38 | `                self.turns = data.get("turns", [])` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 39 | `                self.facts  = data.get("facts", [])` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 40 | `            except Exception:` | Handles a specific failure path; this keeps the program stable when something goes wrong. |
| 41 | `                self.turns = []` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 42 | `                self.facts  = []` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 43 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 44 | `    def save(self):` | Defines a function/method so this behaviour can be called later and kept separate from other logic. |
| 45 | `        data = {"turns": self.turns, "facts": self.facts}` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 46 | `        self.path.write_text(` | Uses filesystem path/file handling so the code can safely read, write, or check files. |
| 47 | `            json.dumps(data, indent=2, ensure_ascii=False),` | Reads or writes JSON, which is used here because memory/todo data must persist after the program closes. |
| 48 | `            encoding="utf-8"` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 49 | `        )` | Closes a multi-line expression or function call that started on previous lines. |
| 50 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 51 | `    # ── Add messages ───────────────────────────────────────────────────────────` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 52 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 53 | `    def add(self, role: str, content: str):` | Defines a function/method so this behaviour can be called later and kept separate from other logic. |
| 54 | `        """Add a message. Role is 'user' or 'assistant'."""` | Docstring/comment text: explains the purpose of the file, class, or function for humans and tools. |
| 55 | `        tz  = pytz.timezone(TIMEZONE)` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 56 | `        now = datetime.now(tz).isoformat()` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 57 | `        self.turns.append({` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 58 | `            "role":    role,` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 59 | `            "content": content,` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 60 | `            "ts":      now          # timestamp — useful for future RAG/search` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 61 | `        })` | Closes a multi-line expression or function call that started on previous lines. |
| 62 | `        self.save()` | Closes a multi-line expression or function call that started on previous lines. |
| 63 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 64 | `    def add_fact(self, fact: str):` | Defines a function/method so this behaviour can be called later and kept separate from other logic. |
| 65 | `        """Store an important fact the user explicitly said to remember."""` | Docstring/comment text: explains the purpose of the file, class, or function for humans and tools. |
| 66 | `        tz  = pytz.timezone(TIMEZONE)` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 67 | `        now = datetime.now(tz).isoformat()` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 68 | `        self.facts.append({"fact": fact, "ts": now})` | Closes a multi-line expression or function call that started on previous lines. |
| 69 | `        self.save()` | Closes a multi-line expression or function call that started on previous lines. |
| 70 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 71 | `    # ── Retrieve for LLM ───────────────────────────────────────────────────────` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 72 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 73 | `    def get_context_messages(self) -> list[dict]:` | Defines a function/method so this behaviour can be called later and kept separate from other logic. |
| 74 | `        """` | Docstring/comment text: explains the purpose of the file, class, or function for humans and tools. |
| 75 | `        Returns last MEMORY_CONTEXT turns formatted for Ollama.` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 76 | `        Strips timestamps (LLM doesn't need them).` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 77 | `        """` | Docstring/comment text: explains the purpose of the file, class, or function for humans and tools. |
| 78 | `        recent = self.turns[-MEMORY_CONTEXT * 2:]` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 79 | `        return [{"role": t["role"], "content": t["content"]} for t in recent]` | Returns a value to the caller and usually ends the current function. |
| 80 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 81 | `    def get_facts_string(self) -> str:` | Defines a function/method so this behaviour can be called later and kept separate from other logic. |
| 82 | `        """Returns stored facts as a string to inject into the system prompt."""` | Docstring/comment text: explains the purpose of the file, class, or function for humans and tools. |
| 83 | `        if not self.facts:` | Conditional check: chooses the next action depending on the current state or user input. |
| 84 | `            return ""` | Returns a value to the caller and usually ends the current function. |
| 85 | `        lines = [f"- {f['fact']}" for f in self.facts[-30:]]  # last 30 facts` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 86 | `        return "Things I know about you:\n" + "\n".join(lines)` | Returns a value to the caller and usually ends the current function. |
| 87 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 88 | `    # ── Stats ──────────────────────────────────────────────────────────────────` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 89 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 90 | `    def stats(self) -> str:` | Defines a function/method so this behaviour can be called later and kept separate from other logic. |
| 91 | `        total  = len(self.turns)` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 92 | `        user_t = sum(1 for t in self.turns if t["role"] == "user")` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 93 | `        facts  = len(self.facts)` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 94 | `        if not self.turns:` | Conditional check: chooses the next action depending on the current state or user input. |
| 95 | `            return "No conversations yet."` | Returns a value to the caller and usually ends the current function. |
| 96 | `        first_ts = self.turns[0].get("ts", "")[:10]` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 97 | `        return (` | Returns a value to the caller and usually ends the current function. |
| 98 | `            f"I have {total} messages stored ({user_t} from you) "` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 99 | `            f"and {facts} personal facts, going back to {first_ts}."` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 100 | `        )` | Closes a multi-line expression or function call that started on previous lines. |
| 101 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 102 | `    def search(self, query: str, n: int = 5) -> list[dict]:` | Defines a function/method so this behaviour can be called later and kept separate from other logic. |
| 103 | `        """Simple keyword search through memory."""` | Docstring/comment text: explains the purpose of the file, class, or function for humans and tools. |
| 104 | `        query_lower = query.lower()` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 105 | `        hits = [` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 106 | `            t for t in self.turns` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 107 | `            if query_lower in t["content"].lower()` | Conditional check: chooses the next action depending on the current state or user input. |
| 108 | `        ]` | Closes a multi-line expression or function call that started on previous lines. |
| 109 | `        return hits[-n:]` | Returns a value to the caller and usually ends the current function. |
| 110 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 111 | `    # ── Intent parsing ─────────────────────────────────────────────────────────` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 112 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 113 | `    def parse_and_handle(self, text: str) -> str \| None:` | Defines a function/method so this behaviour can be called later and kept separate from other logic. |
| 114 | `        text_lower = text.lower().strip()` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 115 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 116 | `        # "Remember that..."` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 117 | `        m = re.search(r"\b(remember\|note\|save\|store)\b\s+(?:that\s+)?(.+)", text_lower)` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 118 | `        if m:` | Conditional check: chooses the next action depending on the current state or user input. |
| 119 | `            fact = m.group(2).strip()` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 120 | `            self.add_fact(fact)` | Closes a multi-line expression or function call that started on previous lines. |
| 121 | `            return f"Got it, I'll remember that {fact}."` | Returns a value to the caller and usually ends the current function. |
| 122 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 123 | `        # Memory stats` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 124 | `        if re.search(r"\b(how much\|how many\|memory stats\|what do you remember\|memory)\b", text_lower):` | Conditional check: chooses the next action depending on the current state or user input. |
| 125 | `            return self.stats()` | Returns a value to the caller and usually ends the current function. |
| 126 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 127 | `        # Search memory` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 128 | `        m = re.search(r"(?:search\|find\|recall\|look up)\s+(?:in\s+)?(?:memory\|history\|past)\s+(.+)", text_lower)` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 129 | `        if m:` | Conditional check: chooses the next action depending on the current state or user input. |
| 130 | `            query = m.group(1).strip()` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 131 | `            results = self.search(query)` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 132 | `            if not results:` | Conditional check: chooses the next action depending on the current state or user input. |
| 133 | `                return f"I couldn't find anything about '{query}' in our history."` | Returns a value to the caller and usually ends the current function. |
| 134 | `            snippets = [f"[{r['role']}] {r['content'][:80]}" for r in results]` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 135 | `            return "Here's what I found:\n" + "\n".join(snippets)` | Returns a value to the caller and usually ends the current function. |
| 136 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 137 | `        return None` | Returns a value to the caller and usually ends the current function. |
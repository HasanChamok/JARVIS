# Notes for `modules/files.py`

## File purpose
File/folder-opening module. It handles commands to open folders, files, and common user locations.

## Main classes and functions

- `open_folder()` starts at line 49: reusable logic block — Open a folder by shortcut name or full path.
- `open_file()` starts at line 77: reusable logic block — Open a file by name or path. Searches if not found directly.
- `list_folder()` starts at line 96: reusable logic block — List contents of a folder.
- `_open_with_association()` starts at line 125: reusable logic block — Open a file using Windows default or a specific app.
- `_extract_target()` starts at line 135: reusable logic block — Strips the trigger verb (open/show/list etc.) and filler words
from the command and returns the target name.
e.g. "open my downloads folder" → "downloads"
- `parse_and_handle()` starts at line 152: reusable logic block — Called by the brain. Returns a response string if this module
can handle the intent, or None to let the LLM handle it.

## Why the sequence/order matters

The file follows the usual Python order: documentation, imports, constants/classes/functions, and finally executable entry logic. That sequence makes dependencies available before they are used.

## Line-by-line notes

| Line | Code | Explanation |
|---:|---|---|
| 1 | `"""` | Docstring/comment text: explains the purpose of the file, class, or function for humans and tools. |
| 2 | `modules/files.py` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 3 | `Handles everything related to opening files and folders.` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 4 | `"""` | Docstring/comment text: explains the purpose of the file, class, or function for humans and tools. |
| 5 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 6 | `import os` | Imports a module so this file can use features that are not built into the current namespace. |
| 7 | `import re` | Imports a module so this file can use features that are not built into the current namespace. |
| 8 | `import subprocess` | Imports a module so this file can use features that are not built into the current namespace. |
| 9 | `from pathlib import Path` | Imports selected classes/functions/constants from another module to keep this file focused and avoid repeating code. |
| 10 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 11 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 12 | `# Common folder shortcuts — add your own below` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 13 | `FOLDER_SHORTCUTS = {` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 14 | `    "desktop":      Path.home() / "Desktop",` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 15 | `    "downloads":    Path.home() / "Downloads",` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 16 | `    "documents":    Path.home() / "Documents",` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 17 | `    "pictures":     Path.home() / "Pictures",` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 18 | `    "music":        Path.home() / "Music",` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 19 | `    "videos":       Path.home() / "Videos",` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 20 | `    "home":         Path.home(),` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 21 | `    # Add your custom folders here:` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 22 | `    # "projects":   Path("C:/Users/YourName/Projects"),` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 23 | `    # "work":       Path("C:/Users/YourName/Work"),` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 24 | `}` | Closes a multi-line expression or function call that started on previous lines. |
| 25 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 26 | `# File type associations (Windows)` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 27 | `FILE_OPENERS = {` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 28 | `    ".pdf":  "start",` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 29 | `    ".docx": "start",` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 30 | `    ".xlsx": "start",` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 31 | `    ".txt":  "notepad",` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 32 | `    ".py":   "code",        # opens in VS Code` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 33 | `    ".mp4":  "start",` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 34 | `    ".mp3":  "start",` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 35 | `    ".jpg":  "start",` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 36 | `    ".png":  "start",` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 37 | `}` | Closes a multi-line expression or function call that started on previous lines. |
| 38 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 39 | `# Trigger words that mean "open something"` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 40 | `OPEN_TRIGGERS = r"\b(open\|go to\|navigate to\|show me\|launch\|take me to\|browse)\b"` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 41 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 42 | `# Trigger words that mean "list contents"` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 43 | `LIST_TRIGGERS = r"\b(list\|show\|what'?s? in\|contents of\|what's inside)\b"` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 44 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 45 | `# Words that signal a file (not a folder)` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 46 | `FILE_SIGNALS = r"\b(file\|pdf\|document\|doc\|video\|image\|photo\|song\|mp3\|mp4\|txt\|excel\|spreadsheet)\b"` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 47 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 48 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 49 | `def open_folder(name: str) -> str:` | Defines a function/method so this behaviour can be called later and kept separate from other logic. |
| 50 | `    """Open a folder by shortcut name or full path."""` | Docstring/comment text: explains the purpose of the file, class, or function for humans and tools. |
| 51 | `    name_lower = name.lower().strip()` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 52 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 53 | `    # Check shortcuts first` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 54 | `    if name_lower in FOLDER_SHORTCUTS:` | Conditional check: chooses the next action depending on the current state or user input. |
| 55 | `        path = FOLDER_SHORTCUTS[name_lower]` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 56 | `        if path.exists():` | Conditional check: chooses the next action depending on the current state or user input. |
| 57 | `            os.startfile(str(path))` | Closes a multi-line expression or function call that started on previous lines. |
| 58 | `            return f"Opening your {name_lower} folder."` | Returns a value to the caller and usually ends the current function. |
| 59 | `        return f"I couldn't find your {name_lower} folder."` | Returns a value to the caller and usually ends the current function. |
| 60 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 61 | `    # Try as a direct path` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 62 | `    path = Path(name).expanduser()` | Uses filesystem path/file handling so the code can safely read, write, or check files. |
| 63 | `    if path.exists() and path.is_dir():` | Conditional check: chooses the next action depending on the current state or user input. |
| 64 | `        os.startfile(str(path))` | Closes a multi-line expression or function call that started on previous lines. |
| 65 | `        return f"Opening {path.name}."` | Returns a value to the caller and usually ends the current function. |
| 66 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 67 | `    # Fuzzy search in home directory` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 68 | `    matches = list(Path.home().rglob(f"*{name}*"))` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 69 | `    dirs = [m for m in matches if m.is_dir()]` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 70 | `    if dirs:` | Conditional check: chooses the next action depending on the current state or user input. |
| 71 | `        os.startfile(str(dirs[0]))` | Closes a multi-line expression or function call that started on previous lines. |
| 72 | `        return f"Found and opening {dirs[0].name}."` | Returns a value to the caller and usually ends the current function. |
| 73 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 74 | `    return f"I couldn't find a folder called '{name}'."` | Returns a value to the caller and usually ends the current function. |
| 75 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 76 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 77 | `def open_file(name: str) -> str:` | Defines a function/method so this behaviour can be called later and kept separate from other logic. |
| 78 | `    """Open a file by name or path. Searches if not found directly."""` | Docstring/comment text: explains the purpose of the file, class, or function for humans and tools. |
| 79 | `    path = Path(name).expanduser()` | Uses filesystem path/file handling so the code can safely read, write, or check files. |
| 80 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 81 | `    # Direct path` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 82 | `    if path.exists() and path.is_file():` | Conditional check: chooses the next action depending on the current state or user input. |
| 83 | `        _open_with_association(path)` | Closes a multi-line expression or function call that started on previous lines. |
| 84 | `        return f"Opening {path.name}."` | Returns a value to the caller and usually ends the current function. |
| 85 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 86 | `    # Fuzzy search` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 87 | `    matches = list(Path.home().rglob(f"*{name}*"))` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 88 | `    files = [m for m in matches if m.is_file()]` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 89 | `    if files:` | Conditional check: chooses the next action depending on the current state or user input. |
| 90 | `        _open_with_association(files[0])` | Closes a multi-line expression or function call that started on previous lines. |
| 91 | `        return f"Found and opening {files[0].name}."` | Returns a value to the caller and usually ends the current function. |
| 92 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 93 | `    return f"I couldn't find a file called '{name}'."` | Returns a value to the caller and usually ends the current function. |
| 94 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 95 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 96 | `def list_folder(name: str) -> str:` | Defines a function/method so this behaviour can be called later and kept separate from other logic. |
| 97 | `    """List contents of a folder."""` | Docstring/comment text: explains the purpose of the file, class, or function for humans and tools. |
| 98 | `    name_lower = name.lower().strip()` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 99 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 100 | `    if name_lower in FOLDER_SHORTCUTS:` | Conditional check: chooses the next action depending on the current state or user input. |
| 101 | `        path = FOLDER_SHORTCUTS[name_lower]` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 102 | `    else:` | Fallback branch used when no earlier condition matched. |
| 103 | `        path = Path(name).expanduser()` | Uses filesystem path/file handling so the code can safely read, write, or check files. |
| 104 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 105 | `    if not path.exists():` | Conditional check: chooses the next action depending on the current state or user input. |
| 106 | `        return f"I can't find the {name} folder."` | Returns a value to the caller and usually ends the current function. |
| 107 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 108 | `    items = sorted(path.iterdir(), key=lambda x: (x.is_file(), x.name.lower()))` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 109 | `    folders = [i.name for i in items if i.is_dir()][:10]` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 110 | `    files   = [i.name for i in items if i.is_file()][:10]` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 111 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 112 | `    parts = []` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 113 | `    if folders:` | Conditional check: chooses the next action depending on the current state or user input. |
| 114 | `        parts.append(f"Folders: {', '.join(folders)}")` | Closes a multi-line expression or function call that started on previous lines. |
| 115 | `    if files:` | Conditional check: chooses the next action depending on the current state or user input. |
| 116 | `        parts.append(f"Files: {', '.join(files)}")` | Closes a multi-line expression or function call that started on previous lines. |
| 117 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 118 | `    total = len(list(path.iterdir()))` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 119 | `    if total > 20:` | Conditional check: chooses the next action depending on the current state or user input. |
| 120 | `        parts.append(f"...and {total - 20} more items.")` | Closes a multi-line expression or function call that started on previous lines. |
| 121 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 122 | `    return f"In your {name} folder — " + ". ".join(parts) + "."` | Returns a value to the caller and usually ends the current function. |
| 123 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 124 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 125 | `def _open_with_association(path: Path):` | Defines a function/method so this behaviour can be called later and kept separate from other logic. |
| 126 | `    """Open a file using Windows default or a specific app."""` | Docstring/comment text: explains the purpose of the file, class, or function for humans and tools. |
| 127 | `    ext = path.suffix.lower()` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 128 | `    opener = FILE_OPENERS.get(ext, "start")` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 129 | `    if opener == "start":` | Conditional check: chooses the next action depending on the current state or user input. |
| 130 | `        os.startfile(str(path))` | Closes a multi-line expression or function call that started on previous lines. |
| 131 | `    else:` | Fallback branch used when no earlier condition matched. |
| 132 | `        subprocess.Popen([opener, str(path)], shell=True)` | Runs an external operating-system command or program; needed for launching apps or Windows tasks. |
| 133 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 134 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 135 | `def _extract_target(text: str, trigger_pattern: str) -> str \| None:` | Defines a function/method so this behaviour can be called later and kept separate from other logic. |
| 136 | `    """` | Docstring/comment text: explains the purpose of the file, class, or function for humans and tools. |
| 137 | `    Strips the trigger verb (open/show/list etc.) and filler words` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 138 | `    from the command and returns the target name.` | Imports selected classes/functions/constants from another module to keep this file focused and avoid repeating code. |
| 139 | `    e.g. "open my downloads folder" → "downloads"` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 140 | `    """` | Docstring/comment text: explains the purpose of the file, class, or function for humans and tools. |
| 141 | `    # Remove the trigger word` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 142 | `    text = re.sub(trigger_pattern, "", text, flags=re.IGNORECASE).strip()` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 143 | `    # Remove filler words` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 144 | `    text = re.sub(r"\b(my\|the\|a\|an\|please\|up\|some\|me)\b", "", text, flags=re.IGNORECASE).strip()` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 145 | `    # Remove trailing/leading noise words` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 146 | `    text = re.sub(r"\b(folder\|directory\|file\|document)\b", "", text, flags=re.IGNORECASE).strip()` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 147 | `    # Clean extra spaces` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 148 | `    text = re.sub(r"\s+", " ", text).strip()` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 149 | `    return text if text else None` | Returns a value to the caller and usually ends the current function. |
| 150 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 151 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 152 | `def parse_and_handle(text: str) -> str \| None:` | Defines a function/method so this behaviour can be called later and kept separate from other logic. |
| 153 | `    """` | Docstring/comment text: explains the purpose of the file, class, or function for humans and tools. |
| 154 | `    Called by the brain. Returns a response string if this module` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 155 | `    can handle the intent, or None to let the LLM handle it.` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 156 | `    """` | Docstring/comment text: explains the purpose of the file, class, or function for humans and tools. |
| 157 | `    text_lower = text.lower().strip()` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 158 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 159 | `    # ── List folder contents ───────────────────────────────────────────────────` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 160 | `    if re.search(LIST_TRIGGERS, text_lower):` | Conditional check: chooses the next action depending on the current state or user input. |
| 161 | `        # Check if any known shortcut is mentioned` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 162 | `        for name in FOLDER_SHORTCUTS:` | Loop: repeats the following block for every item in a collection or range. |
| 163 | `            if name in text_lower:` | Conditional check: chooses the next action depending on the current state or user input. |
| 164 | `                return list_folder(name)` | Returns a value to the caller and usually ends the current function. |
| 165 | `        # Extract target generically` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 166 | `        target = _extract_target(text_lower, LIST_TRIGGERS)` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 167 | `        if target:` | Conditional check: chooses the next action depending on the current state or user input. |
| 168 | `            return list_folder(target)` | Returns a value to the caller and usually ends the current function. |
| 169 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 170 | `    # ── Open something ─────────────────────────────────────────────────────────` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 171 | `    if re.search(OPEN_TRIGGERS, text_lower):` | Conditional check: chooses the next action depending on the current state or user input. |
| 172 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 173 | `        # Check if any known folder shortcut is mentioned directly` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 174 | `        for name in FOLDER_SHORTCUTS:` | Loop: repeats the following block for every item in a collection or range. |
| 175 | `            if name in text_lower:` | Conditional check: chooses the next action depending on the current state or user input. |
| 176 | `                # Is it a file signal? If so, search for a file with that name` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 177 | `                if re.search(FILE_SIGNALS, text_lower):` | Conditional check: chooses the next action depending on the current state or user input. |
| 178 | `                    target = _extract_target(text_lower, OPEN_TRIGGERS)` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 179 | `                    if target:` | Conditional check: chooses the next action depending on the current state or user input. |
| 180 | `                        return open_file(target)` | Returns a value to the caller and usually ends the current function. |
| 181 | `                return open_folder(name)` | Returns a value to the caller and usually ends the current function. |
| 182 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 183 | `        # Extract generic target` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 184 | `        target = _extract_target(text_lower, OPEN_TRIGGERS)` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 185 | `        if not target:` | Conditional check: chooses the next action depending on the current state or user input. |
| 186 | `            return None` | Returns a value to the caller and usually ends the current function. |
| 187 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 188 | `        # Decide: file or folder?` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 189 | `        if re.search(FILE_SIGNALS, text_lower):` | Conditional check: chooses the next action depending on the current state or user input. |
| 190 | `            return open_file(target)` | Returns a value to the caller and usually ends the current function. |
| 191 | `        else:` | Fallback branch used when no earlier condition matched. |
| 192 | `            # Try folder first, then file` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 193 | `            result = open_folder(target)` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 194 | `            if "couldn't find" in result:` | Conditional check: chooses the next action depending on the current state or user input. |
| 195 | `                result = open_file(target)` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 196 | `            return result` | Returns a value to the caller and usually ends the current function. |
| 197 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 198 | `    return None  # not handled here` | Returns a value to the caller and usually ends the current function. |
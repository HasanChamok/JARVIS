# Notes for `setup.bat`

## File purpose
Windows setup script. It installs required Python packages, checks Ollama, checks GPU support, and prints start commands.

## Why the sequence/order matters
The batch file checks prerequisites before installing packages. This matters because dependency installation or GPU checks are useless if Python is not installed.

## Line-by-line notes
| Line | Content | Explanation |
|---:|---|---|
| 1 | `g@echo off` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 2 | `title JARVIS v2 Setup` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 3 | `echo.` | Prints a message so the user knows what setup step is happening. |
| 4 | `echo  ============================================` | Prints a message so the user knows what setup step is happening. |
| 5 | `echo   J.A.R.V.I.S  v2  Setup  (Windows + RTX)` | Prints a message so the user knows what setup step is happening. |
| 6 | `echo  ============================================` | Prints a message so the user knows what setup step is happening. |
| 7 | `echo.` | Prints a message so the user knows what setup step is happening. |
| 8 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 9 | `python --version >nul 2>&1` | Runs Python to check installation or verify GPU support. |
| 10 | `if errorlevel 1 (` | Checks whether the previous command failed, then runs the error/warning path. |
| 11 | `    echo [ERROR] Python not found. Install from https://python.org` | Prints a message so the user knows what setup step is happening. |
| 12 | `    pause & exit /b 1` | Keeps the window open so the user can read the final result. |
| 13 | `)` | Closes a multi-line expression or function call that started on previous lines. |
| 14 | `echo [OK] Python found` | Prints a message so the user knows what setup step is happening. |
| 15 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 16 | `echo.` | Prints a message so the user knows what setup step is happening. |
| 17 | `echo [1/6] Installing PyTorch with CUDA 12.1 for RTX 4050...` | Prints a message so the user knows what setup step is happening. |
| 18 | `pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cu121 -q` | Installs a Python dependency required by JARVIS. |
| 19 | `echo [OK] PyTorch installed` | Prints a message so the user knows what setup step is happening. |
| 20 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 21 | `echo.` | Prints a message so the user knows what setup step is happening. |
| 22 | `echo [2/6] Installing core dependencies...` | Prints a message so the user knows what setup step is happening. |
| 23 | `pip install faster-whisper kokoro sounddevice soundfile pytz -q` | Installs a Python dependency required by JARVIS. |
| 24 | `echo [OK] Core deps done` | Prints a message so the user knows what setup step is happening. |
| 25 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 26 | `echo.` | Prints a message so the user knows what setup step is happening. |
| 27 | `echo [3/6] Installing real-time and memory deps...` | Prints a message so the user knows what setup step is happening. |
| 28 | `pip install ollama requests -q` | Installs a Python dependency required by JARVIS. |
| 29 | `echo [OK] Real-time deps done` | Prints a message so the user knows what setup step is happening. |
| 30 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 31 | `echo.` | Prints a message so the user knows what setup step is happening. |
| 32 | `echo [4/6] Installing GUI...` | Prints a message so the user knows what setup step is happening. |
| 33 | `pip install PyQt6 -q` | Installs a Python dependency required by JARVIS. |
| 34 | `echo [OK] PyQt6 installed` | Prints a message so the user knows what setup step is happening. |
| 35 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 36 | `echo.` | Prints a message so the user knows what setup step is happening. |
| 37 | `echo [5/6] Checking Ollama...` | Prints a message so the user knows what setup step is happening. |
| 38 | `ollama --version >nul 2>&1` | Checks or downloads the local LLM model used by JARVIS. |
| 39 | `if errorlevel 1 (` | Checks whether the previous command failed, then runs the error/warning path. |
| 40 | `    echo [WARN] Ollama not installed.` | Prints a message so the user knows what setup step is happening. |
| 41 | `    echo        Download from: https://ollama.com/download` | Prints a message so the user knows what setup step is happening. |
| 42 | `    echo        Then run: ollama pull llama3.2` | Prints a message so the user knows what setup step is happening. |
| 43 | `) else (` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 44 | `    echo [OK] Ollama found — pulling llama3.2...` | Prints a message so the user knows what setup step is happening. |
| 45 | `    ollama pull llama3.2` | Checks or downloads the local LLM model used by JARVIS. |
| 46 | `)` | Closes a multi-line expression or function call that started on previous lines. |
| 47 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 48 | `echo.` | Prints a message so the user knows what setup step is happening. |
| 49 | `echo [6/6] Verifying GPU...` | Prints a message so the user knows what setup step is happening. |
| 50 | `python -c "import torch; g=torch.cuda.get_device_name(0) if torch.cuda.is_available() else 'NOT FOUND'; m=torch.cuda.get_device_properties(0).total_memory//1024**3 if torch.cuda...` | Runs Python to check installation or verify GPU support. |
| 51 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 52 | `echo.` | Prints a message so the user knows what setup step is happening. |
| 53 | `echo  ============================================` | Prints a message so the user knows what setup step is happening. |
| 54 | `echo  JARVIS v2 is ready!` | Prints a message so the user knows what setup step is happening. |
| 55 | `echo.` | Prints a message so the user knows what setup step is happening. |
| 56 | `echo  Commands:` | Prints a message so the user knows what setup step is happening. |
| 57 | `echo    Start (headless):  python main.py` | Prints a message so the user knows what setup step is happening. |
| 58 | `echo    Start (with GUI):  python main.py --gui` | Prints a message so the user knows what setup step is happening. |
| 59 | `echo    Auto-start setup:  python autostart.py` | Prints a message so the user knows what setup step is happening. |
| 60 | `echo    Remove auto-start: python autostart.py --remove` | Prints a message so the user knows what setup step is happening. |
| 61 | `echo.` | Prints a message so the user knows what setup step is happening. |
| 62 | `echo  Before starting, run in a separate terminal:` | Prints a message so the user knows what setup step is happening. |
| 63 | `echo    ollama serve` | Prints a message so the user knows what setup step is happening. |
| 64 | `echo  ============================================` | Prints a message so the user knows what setup step is happening. |
| 65 | `echo.` | Prints a message so the user knows what setup step is happening. |
| 66 | `pause` | Keeps the window open so the user can read the final result. |
# Notes for `modules/apps.py`

## File purpose
Application-launching module. It recognises app-opening commands and starts Windows applications or known executables.

## Main classes and functions

- `launch_app()` starts at line 75: reusable logic block — Launch an app by name. Fuzzy matches the registry.
- `_run()` starts at line 93: reusable logic block — Actually run the command.
- `parse_and_handle()` starts at line 109: reusable logic block — Returns response string if this module handles it, else None.

## Why the sequence/order matters

The file follows the usual Python order: documentation, imports, constants/classes/functions, and finally executable entry logic. That sequence makes dependencies available before they are used.

## Line-by-line notes

| Line | Code | Explanation |
|---:|---|---|
| 1 | `"""` | Docstring/comment text: explains the purpose of the file, class, or function for humans and tools. |
| 2 | `modules/apps.py` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 3 | `Handles launching applications on Windows.` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 4 | `"""` | Docstring/comment text: explains the purpose of the file, class, or function for humans and tools. |
| 5 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 6 | `import re` | Imports a module so this file can use features that are not built into the current namespace. |
| 7 | `import subprocess` | Imports a module so this file can use features that are not built into the current namespace. |
| 8 | `import os` | Imports a module so this file can use features that are not built into the current namespace. |
| 9 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 10 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 11 | `# ── App registry — add YOUR apps here ─────────────────────────────────────────` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 12 | `# Format: "what you say": "what to run"` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 13 | `APP_REGISTRY = {` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 14 | `    # Browsers` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 15 | `    "chrome":           "chrome",` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 16 | `    "google chrome":    "chrome",` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 17 | `    "firefox":          "firefox",` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 18 | `    "edge":             "msedge",` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 19 | `    "browser":          "chrome",` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 20 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 21 | `    # Dev tools` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 22 | `    "vs code":          "code",` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 23 | `    "vscode":           "code",` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 24 | `    "visual studio code": "code",` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 25 | `    "terminal":         "wt",           # Windows Terminal` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 26 | `    "powershell":       "powershell",` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 27 | `    "cmd":              "cmd",` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 28 | `    "git bash":         "git-bash",` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 29 | `    "jupyter":          "jupyter notebook",` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 30 | `    "pycharm":          "pycharm64",` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 31 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 32 | `    # Office / productivity` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 33 | `    "word":             "winword",` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 34 | `    "excel":            "excel",` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 35 | `    "powerpoint":       "powerpnt",` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 36 | `    "notepad":          "notepad",` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 37 | `    "notepad++":        "notepad++",` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 38 | `    "calculator":       "calc",` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 39 | `    "paint":            "mspaint",` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 40 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 41 | `    # Communication` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 42 | `    "discord":          "discord",` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 43 | `    "slack":            "slack",` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 44 | `    "teams":            "teams",` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 45 | `    "zoom":             "zoom",` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 46 | `    "whatsapp":         "whatsapp",` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 47 | `    "telegram":         "telegram",` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 48 | `    "outlook":          "outlook",` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 49 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 50 | `    # Media & entertainment` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 51 | `    "spotify":          "spotify",` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 52 | `    "vlc":              "vlc",` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 53 | `    "steam":            "steam",` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 54 | `    "epic games":       "epicgameslauncher",` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 55 | `    "obs":              "obs64",` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 56 | `    "premiere":         "premiere",` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 57 | `    "photoshop":        "photoshop",` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 58 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 59 | `    # System` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 60 | `    "task manager":     "taskmgr",` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 61 | `    "settings":         "ms-settings:",` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 62 | `    "control panel":    "control",` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 63 | `    "file explorer":    "explorer",` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 64 | `    "explorer":         "explorer",` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 65 | `    "files":            "explorer",` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 66 | `    "bluetooth":        "ms-settings:bluetooth",` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 67 | `    "wifi":             "ms-settings:network-wifi",` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 68 | `    "display settings": "ms-settings:display",` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 69 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 70 | `    # Add your own apps:` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 71 | `    # "my app": "myapp.exe",` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 72 | `}` | Closes a multi-line expression or function call that started on previous lines. |
| 73 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 74 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 75 | `def launch_app(name: str) -> str:` | Defines a function/method so this behaviour can be called later and kept separate from other logic. |
| 76 | `    """Launch an app by name. Fuzzy matches the registry."""` | Docstring/comment text: explains the purpose of the file, class, or function for humans and tools. |
| 77 | `    name_lower = name.lower().strip()` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 78 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 79 | `    # Exact match` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 80 | `    if name_lower in APP_REGISTRY:` | Conditional check: chooses the next action depending on the current state or user input. |
| 81 | `        cmd = APP_REGISTRY[name_lower]` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 82 | `        return _run(cmd, name)` | Returns a value to the caller and usually ends the current function. |
| 83 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 84 | `    # Partial match` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 85 | `    for key, cmd in APP_REGISTRY.items():` | Loop: repeats the following block for every item in a collection or range. |
| 86 | `        if key in name_lower or name_lower in key:` | Conditional check: chooses the next action depending on the current state or user input. |
| 87 | `            return _run(cmd, key)` | Returns a value to the caller and usually ends the current function. |
| 88 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 89 | `    # Try running directly (in case it's an installed app)` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 90 | `    return _run(name_lower, name)` | Returns a value to the caller and usually ends the current function. |
| 91 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 92 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 93 | `def _run(cmd: str, display_name: str) -> str:` | Defines a function/method so this behaviour can be called later and kept separate from other logic. |
| 94 | `    """Actually run the command."""` | Docstring/comment text: explains the purpose of the file, class, or function for humans and tools. |
| 95 | `    try:` | Starts error-handling block so failures can be caught without crashing the whole assistant. |
| 96 | `        if cmd.startswith("ms-"):` | Conditional check: chooses the next action depending on the current state or user input. |
| 97 | `            os.startfile(cmd)` | Closes a multi-line expression or function call that started on previous lines. |
| 98 | `        else:` | Fallback branch used when no earlier condition matched. |
| 99 | `            subprocess.Popen(` | Runs an external operating-system command or program; needed for launching apps or Windows tasks. |
| 100 | `                cmd, shell=True,` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 101 | `                stdout=subprocess.DEVNULL,` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 102 | `                stderr=subprocess.DEVNULL` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 103 | `            )` | Closes a multi-line expression or function call that started on previous lines. |
| 104 | `        return f"Launching {display_name} now."` | Returns a value to the caller and usually ends the current function. |
| 105 | `    except Exception as e:` | Handles a specific failure path; this keeps the program stable when something goes wrong. |
| 106 | `        return f"I couldn't launch {display_name}. Error: {e}"` | Returns a value to the caller and usually ends the current function. |
| 107 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 108 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 109 | `def parse_and_handle(text: str) -> str \| None:` | Defines a function/method so this behaviour can be called later and kept separate from other logic. |
| 110 | `    """` | Docstring/comment text: explains the purpose of the file, class, or function for humans and tools. |
| 111 | `    Returns response string if this module handles it, else None.` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 112 | `    """` | Docstring/comment text: explains the purpose of the file, class, or function for humans and tools. |
| 113 | `    text_lower = text.lower().strip()` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 114 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 115 | `    # Match: "open/launch/start/run X"` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 116 | `    m = re.search(` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 117 | `        r"\b(open\|launch\|start\|run)\b\s+(.+?)(?:\s+app\|\s+application\|\s+program)?$",` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 118 | `        text_lower` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 119 | `    )` | Closes a multi-line expression or function call that started on previous lines. |
| 120 | `    if m:` | Conditional check: chooses the next action depending on the current state or user input. |
| 121 | `        target = m.group(2).strip()` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 122 | `        # Don't steal file/folder intents` | Comment/section header: describes the next block; Python ignores it at runtime. |
| 123 | `        if any(w in target for w in ["file", "folder", "document", "my "]):` | Conditional check: chooses the next action depending on the current state or user input. |
| 124 | `            return None` | Returns a value to the caller and usually ends the current function. |
| 125 | `        return launch_app(target)` | Returns a value to the caller and usually ends the current function. |
| 126 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 127 | `    return None` | Returns a value to the caller and usually ends the current function. |
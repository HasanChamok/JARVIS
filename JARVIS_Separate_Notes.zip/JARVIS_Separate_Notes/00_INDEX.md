# JARVIS Project Notes Index

These notes were generated as separate files. Start with `main.py`, then `jarvis.py`, then each module.

## Recommended learning order

1. `main.py` — understand how the app starts.
2. `config.py` — understand settings/constants.
3. `jarvis.py` — understand the main brain and routing sequence.
4. `modules/speech.py` — understand microphone and speaking.
5. `modules/memory.py` and `modules/todo.py` — understand JSON persistence.
6. `modules/files.py`, `modules/apps.py`, `modules/realtime.py`, `modules/personality.py` — understand command modules.
7. `gui.py` — understand the dashboard and threading.
8. `autostart.py` and `setup.bat` — understand Windows setup/startup.

## All note files

- `.git/HEAD` → `.git__HEAD.notes.md`
- `.git/config` → `.git__config.notes.md`
- `.git/description` → `.git__description.notes.md`
- `.git/gk/config` → `.git__gk__config.notes.md`
- `.git/hooks/applypatch-msg.sample` → `.git__hooks__applypatch-msg.sample.notes.md`
- `.git/hooks/commit-msg.sample` → `.git__hooks__commit-msg.sample.notes.md`
- `.git/hooks/fsmonitor-watchman.sample` → `.git__hooks__fsmonitor-watchman.sample.notes.md`
- `.git/hooks/post-update.sample` → `.git__hooks__post-update.sample.notes.md`
- `.git/hooks/pre-applypatch.sample` → `.git__hooks__pre-applypatch.sample.notes.md`
- `.git/hooks/pre-commit.sample` → `.git__hooks__pre-commit.sample.notes.md`
- `.git/hooks/pre-merge-commit.sample` → `.git__hooks__pre-merge-commit.sample.notes.md`
- `.git/hooks/pre-push.sample` → `.git__hooks__pre-push.sample.notes.md`
- `.git/hooks/pre-rebase.sample` → `.git__hooks__pre-rebase.sample.notes.md`
- `.git/hooks/pre-receive.sample` → `.git__hooks__pre-receive.sample.notes.md`
- `.git/hooks/prepare-commit-msg.sample` → `.git__hooks__prepare-commit-msg.sample.notes.md`
- `.git/hooks/push-to-checkout.sample` → `.git__hooks__push-to-checkout.sample.notes.md`
- `.git/hooks/sendemail-validate.sample` → `.git__hooks__sendemail-validate.sample.notes.md`
- `.git/hooks/update.sample` → `.git__hooks__update.sample.notes.md`
- `.git/info/exclude` → `.git__info__exclude.notes.md`
- `LEARNING_ROADMAP.md` → `LEARNING_ROADMAP.md.notes.md`
- `__pycache__/config.cpython-311.pyc` → `__pycache____config.cpython-311.pyc.notes.md`
- `__pycache__/config.cpython-314.pyc` → `__pycache____config.cpython-314.pyc.notes.md`
- `__pycache__/gui.cpython-311.pyc` → `__pycache____gui.cpython-311.pyc.notes.md`
- `__pycache__/jarvis.cpython-311.pyc` → `__pycache____jarvis.cpython-311.pyc.notes.md`
- `__pycache__/jarvis.cpython-314.pyc` → `__pycache____jarvis.cpython-314.pyc.notes.md`
- `autostart.py` → `autostart.py.notes.md`
- `config.py` → `config.py.notes.md`
- `data/memory.json` → `data__memory.json.notes.md`
- `gui.py` → `gui.py.notes.md`
- `jarvis.py` → `jarvis.py.notes.md`
- `main.py` → `main.py.notes.md`
- `modules/__init__.py` → `modules____init__.py.notes.md`
- `modules/__pycache__/__init__.cpython-311.pyc` → `modules____pycache______init__.cpython-311.pyc.notes.md`
- `modules/__pycache__/apps.cpython-311.pyc` → `modules____pycache____apps.cpython-311.pyc.notes.md`
- `modules/__pycache__/files.cpython-311.pyc` → `modules____pycache____files.cpython-311.pyc.notes.md`
- `modules/__pycache__/memory.cpython-311.pyc` → `modules____pycache____memory.cpython-311.pyc.notes.md`
- `modules/__pycache__/personality.cpython-311.pyc` → `modules____pycache____personality.cpython-311.pyc.notes.md`
- `modules/__pycache__/realtime.cpython-311.pyc` → `modules____pycache____realtime.cpython-311.pyc.notes.md`
- `modules/__pycache__/speech.cpython-311.pyc` → `modules____pycache____speech.cpython-311.pyc.notes.md`
- `modules/__pycache__/todo.cpython-311.pyc` → `modules____pycache____todo.cpython-311.pyc.notes.md`
- `modules/apps.py` → `modules__apps.py.notes.md`
- `modules/files.py` → `modules__files.py.notes.md`
- `modules/memory.py` → `modules__memory.py.notes.md`
- `modules/personality.py` → `modules__personality.py.notes.md`
- `modules/realtime.py` → `modules__realtime.py.notes.md`
- `modules/speech.py` → `modules__speech.py.notes.md`
- `modules/todo.py` → `modules__todo.py.notes.md`
- `setup.bat` → `setup.bat.notes.md`
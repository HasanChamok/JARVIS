# Notes for `main.py`

## File purpose
Program entry point. It parses command-line options and starts either terminal mode or GUI mode.

## Main classes and functions

- `run_headless()` starts at line 15: reusable logic block
- `run_gui()` starts at line 21: reusable logic block

## Why the sequence/order matters

The file first imports tools, then adjusts `sys.path`, then defines startup functions, then uses the `__main__` guard. This order matters because functions must exist before the argument parser chooses which one to call.

## Line-by-line notes

| Line | Code | Explanation |
|---:|---|---|
| 1 | `"""` | Docstring/comment text: explains the purpose of the file, class, or function for humans and tools. |
| 2 | `main.py — Entry point.` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 3 | `Run this file to start JARVIS.` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 4 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 5 | `    python main.py           # headless (terminal only)` | Closes a multi-line expression or function call that started on previous lines. |
| 6 | `    python main.py --gui     # with GUI dashboard` | Executable statement: performs part of this file’s logic in the sequence shown. |
| 7 | `"""` | Docstring/comment text: explains the purpose of the file, class, or function for humans and tools. |
| 8 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 9 | `import sys` | Imports a module so this file can use features that are not built into the current namespace. |
| 10 | `import argparse` | Imports a module so this file can use features that are not built into the current namespace. |
| 11 | `import os` | Imports a module so this file can use features that are not built into the current namespace. |
| 12 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 13 | `sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))` | Closes a multi-line expression or function call that started on previous lines. |
| 14 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 15 | `def run_headless():` | Defines a function/method so this behaviour can be called later and kept separate from other logic. |
| 16 | `    from jarvis import JARVIS` | Imports selected classes/functions/constants from another module to keep this file focused and avoid repeating code. |
| 17 | `    j = JARVIS()` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 18 | `    j.start()` | Closes a multi-line expression or function call that started on previous lines. |
| 19 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 20 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 21 | `def run_gui():` | Defines a function/method so this behaviour can be called later and kept separate from other logic. |
| 22 | `    from PyQt6.QtWidgets import QApplication` | Imports selected classes/functions/constants from another module to keep this file focused and avoid repeating code. |
| 23 | `    from gui import JARVISDashboard` | Imports selected classes/functions/constants from another module to keep this file focused and avoid repeating code. |
| 24 | `    app = QApplication(sys.argv)` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 25 | `    app.setApplicationName("JARVIS")` | Closes a multi-line expression or function call that started on previous lines. |
| 26 | `    window = JARVISDashboard()` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 27 | `    window.show()` | Closes a multi-line expression or function call that started on previous lines. |
| 28 | `    sys.exit(app.exec())` | Closes a multi-line expression or function call that started on previous lines. |
| 29 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 30 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 31 | `if __name__ == "__main__":` | Entry-point guard: this block runs only when the file is executed directly, not when imported by another file. |
| 32 | `    parser = argparse.ArgumentParser(description="JARVIS Personal AI Assistant")` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 33 | `    parser.add_argument("--gui", action="store_true", help="Launch with GUI dashboard")` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 34 | `    args = parser.parse_args()` | Assignment: stores a value in a variable/attribute so later lines can reuse it instead of recalculating or hardcoding it. |
| 35 | `` | Blank line used to visually separate sections so the code is easier to read. |
| 36 | `    if args.gui:` | Conditional check: chooses the next action depending on the current state or user input. |
| 37 | `        run_gui()` | Closes a multi-line expression or function call that started on previous lines. |
| 38 | `    else:` | Fallback branch used when no earlier condition matched. |
| 39 | `        run_headless()` | Closes a multi-line expression or function call that started on previous lines. |